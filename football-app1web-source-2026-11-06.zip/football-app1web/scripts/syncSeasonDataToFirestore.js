const fs = require("fs");
const path = require("path");

const PROJECT_ID = "match-bb30c";
const DATABASE_ID = "(default)";
const PROJECT_ROOT = path.resolve(__dirname, "..");
const DATA_PATH = path.join(PROJECT_ROOT, "data", "premierLeagueSeason.json");
const FIREBASE_SCOPES = [
  "email",
  "openid",
  "https://www.googleapis.com/auth/cloudplatformprojects.readonly",
  "https://www.googleapis.com/auth/firebase",
  "https://www.googleapis.com/auth/cloud-platform",
];

const getFirebaseToolsAuth = () => {
  const configuredPath = process.env.FIREBASE_TOOLS_AUTH_PATH;
  const windowsGlobalPath = process.env.APPDATA
    ? path.join(
        process.env.APPDATA,
        "npm",
        "node_modules",
        "firebase-tools",
        "lib",
        "auth.js"
      )
    : "";
  const authPath = configuredPath || windowsGlobalPath;

  if (!authPath || !fs.existsSync(authPath)) {
    throw new Error(
      "ไม่พบ Firebase CLI กรุณาติดตั้ง firebase-tools และรัน firebase login ก่อน"
    );
  }

  return require(authPath);
};

const getAccessToken = async () => {
  const auth = getFirebaseToolsAuth();
  const account = auth.getGlobalDefaultAccount();

  if (!account?.tokens?.refresh_token) {
    throw new Error("ยังไม่ได้เข้าสู่ระบบ Firebase กรุณารัน firebase login ก่อน");
  }

  const tokens = await auth.getAccessToken(
    account.tokens.refresh_token,
    FIREBASE_SCOPES
  );

  if (!tokens?.access_token) {
    throw new Error("ไม่สามารถรับสิทธิ์เชื่อมต่อ Firebase ได้");
  }

  return tokens.access_token;
};

const encodeValue = (value) => {
  if (value === null || value === undefined) {
    return { nullValue: null };
  }

  if (typeof value === "boolean") {
    return { booleanValue: value };
  }

  if (typeof value === "number") {
    return Number.isInteger(value)
      ? { integerValue: String(value) }
      : { doubleValue: value };
  }

  if (typeof value === "string") {
    return { stringValue: value };
  }

  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map(encodeValue) } };
  }

  return {
    mapValue: {
      fields: Object.fromEntries(
        Object.entries(value).map(([key, nestedValue]) => [
          key,
          encodeValue(nestedValue),
        ])
      ),
    },
  };
};

const encodeFields = (document) =>
  Object.fromEntries(
    Object.entries(document).map(([key, value]) => [key, encodeValue(value)])
  );

const createWrites = (documentRoot, collection, documents, extraFields = {}) =>
  documents.map((document) => ({
    update: {
      name: `${documentRoot}/${collection}/${document.id}`,
      fields: encodeFields({ ...document, ...extraFields }),
    },
  }));

const writeBatch = async (token, documentRoot, writes) => {
  const response = await fetch(
    `https://firestore.googleapis.com/v1/${documentRoot}:batchWrite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ writes }),
    }
  );
  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      result?.error?.message || `Firestore upload failed: ${response.status}`
    );
  }

  const failedWrites = (result.status ?? []).filter(
    (status) => status && Object.keys(status).length > 0
  );

  if ((result.writeResults?.length ?? 0) !== writes.length || failedWrites.length) {
    throw new Error(
      `Firestore เขียนข้อมูลไม่ครบ: ${result.writeResults?.length ?? 0}/${writes.length}`
    );
  }
};

const syncSeasonData = async () => {
  const data = JSON.parse(fs.readFileSync(DATA_PATH, "utf8"));
  const currentSeason = Number(data.season?.startYear);
  const currentMatchSeasons = new Set(
    (data.matches ?? []).map((match) => Number(match?.season?.startYear))
  );

  if (
    data.matches?.length !== 380 ||
    data.standings?.length !== 20 ||
    data.teams?.length !== 20 ||
    currentMatchSeasons.size !== 1 ||
    !currentMatchSeasons.has(currentSeason)
  ) {
    throw new Error("ตรวจข้อมูลฤดูกาลไม่ผ่าน จึงยกเลิกการอัปโหลด");
  }

  const token = await getAccessToken();
  const documentRoot = `projects/${PROJECT_ID}/databases/${DATABASE_ID}/documents`;
  const collectionCounts = {
    matches: data.matches.length,
    standings: data.standings.length,
    teams: data.teams.length,
  };
  const writes = [
    ...createWrites(documentRoot, "matches", data.matches, {
      seasonLabel: data.seasonLabel,
    }),
    ...createWrites(documentRoot, "standings", data.standings, {
      seasonLabel: data.seasonLabel,
    }),
    ...createWrites(documentRoot, "teams", data.teams, {
      seasonLabel: data.seasonLabel,
      lastSyncedAt: data.syncedAt,
    }),
  ];

  for (let index = 0; index < writes.length; index += 400) {
    await writeBatch(token, documentRoot, writes.slice(index, index + 400));
  }

  console.log(
    JSON.stringify(
      {
        currentSeason: data.seasonLabel,
        syncedAt: data.syncedAt,
        collections: collectionCounts,
        totalWrites: writes.length,
      },
      null,
      2
    )
  );
};

syncSeasonData().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
