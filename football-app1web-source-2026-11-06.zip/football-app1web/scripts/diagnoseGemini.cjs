const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const env = Object.fromEntries(fs.readFileSync(path.join(root, ".env.local"), "utf8")
  .split(/\r?\n/).filter(line => line && !line.trim().startsWith("#") && line.includes("="))
  .map(line => {
    const index = line.indexOf("=");
    return [line.slice(0, index).trim(), line.slice(index + 1).trim().replace(/^(["'])(.*)\1$/, "$2")];
  }));
const isMobile = process.argv.includes("--mobile");
const key = isMobile ? env.EXPO_PUBLIC_GEMINI_API_KEY_MOBILE : env.EXPO_PUBLIC_GEMINI_API_KEY_WEB || env.EXPO_PUBLIC_GEMINI_API_KEY;
const bundleDir = path.join(root, "dist", "_expo", "static", "js", "web");
const bundle = fs.readFileSync(path.join(bundleDir, fs.readdirSync(bundleDir).find(name => name.endsWith(".js"))), "utf8");
console.log(JSON.stringify({ webKeyConfigured: Boolean(key), webKeyInBundle: Boolean(key && bundle.includes(key)), mobileKeyInBundle: Boolean(env.EXPO_PUBLIC_GEMINI_API_KEY_MOBILE && bundle.includes(env.EXPO_PUBLIC_GEMINI_API_KEY_MOBILE)) }));
if (process.argv.includes("--live")) {
  (async () => {
    const response = await fetch("https://match-bb30c.web.app/", { cache: "no-store" });
    const html = await response.text();
    const scriptPath = html.match(/src="([^"]+\/index-[^"]+\.js)"/)?.[1];
    if (!response.ok || !scriptPath) throw new Error("Unable to find the deployed web bundle.");
    const scriptResponse = await fetch(new URL(scriptPath, response.url), { cache: "no-store" });
    const deployed = await scriptResponse.text();
    const sameBundle = deployed === bundle;
    console.log(JSON.stringify({ hostingStatus: response.status, scriptStatus: scriptResponse.status, sameBundle, deployedWebKeyMatches: deployed.includes(key), deployedModelMatches: deployed.includes("gemini-3.5-flash-lite") }));
    if (!sameBundle || !scriptResponse.ok) process.exitCode = 1;
  })().catch(error => { console.error(error.message); process.exitCode = 1; });
}
if (process.argv.includes("--request")) {
  (async () => {
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key, ...(!isMobile && { Referer: "https://match-bb30c.web.app/" }) },
      body: JSON.stringify({ contents: [{ parts: [{ text: "Reply with exactly OK" }] }], generationConfig: { maxOutputTokens: 10 } }),
    });
    const payload = await response.json();
    console.log(JSON.stringify({ status: response.status, text: payload.candidates?.[0]?.content?.parts?.map(part => part.text || "").join(""), error: payload.error?.message, reasons: payload.error?.details?.map(detail => detail.reason).filter(Boolean) }));
  })().catch(error => { console.error(error.message); process.exitCode = 1; });
}
if (process.argv.includes("--analysis")) {
  const vm = require("vm");
  const data = JSON.parse(fs.readFileSync(path.join(root, "data", "premierLeagueSeason.json"), "utf8"));
  const source = fs.readFileSync(path.join(root, "ai", "dataDrivenAnalysisV3.js"), "utf8")
    .replace(/^import[\s\S]*?;\r?\n/gm, "")
    .replace(/export async function /g, "async function ");
  const sandbox = {
    Constants: { expoConfig: { extra: {} } }, Platform: { OS: isMobile ? "android" : "web" },
    process: { env }, console, setTimeout,
    fetch: async (...args) => {
      if (!isMobile) args[1].headers.Referer = "https://match-bb30c.web.app/";
      const response = await fetch(...args);
      console.log(JSON.stringify({ analysisHttpStatus: response.status }));
      return response;
    },
    PREMIER_LEAGUE_SEASON: data.season,
    loadPremierLeagueStandingsForAI: async () => data.standings,
    loadPremierLeagueMatchesForAI: async () => data.matches,
    loadPremierLeagueHistoricalMatchesForAI: async () => data.historicalSeasonMatches.flatMap(season => season.matches),
    loadPremierLeagueTeamSquadForAI: async id => data.teams.find(team => String(team.id) === String(id))?.squad || [],
  };
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox);
  vm.runInContext("predictMatchWithAudit('Arsenal', 'Liverpool')", sandbox).then(result => {
    const headings = [...result.analysis.matchAll(/(?:^|\n)\s*(?:\*\*)?([1-7])\./g)].map(match => Number(match[1]));
    const usedFallback = result.analysis.includes("สถิติสำรอง") || result.analysis.includes("ไม่ใช่ Gemini");
    console.log(JSON.stringify({ analysisCharacters: result.analysis.length, usedFallback, headings, mentionsArsenal: result.analysis.includes("Arsenal"), mentionsLiverpool: result.analysis.includes("Liverpool") }));
    if (usedFallback || new Set(headings).size !== 7) process.exitCode = 1;
  }).catch(error => { console.error(error.message); process.exitCode = 1; });
}
