/* Standalone report generator. Reads only completed, real backtest CSV rows. */
const fs = require("fs");
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "backtesting", "results", "backtest_results.csv");
const OUTPUT = path.join(ROOT, "backtesting", "results", "confusion_matrix_interpretation.md");
const CLASSES = ["HOME", "DRAW", "AWAY"];

const parseLine = (line) => { const cells = []; let value = ""; let quoted = false; for (let i = 0; i < line.length; i += 1) { const char = line[i]; if (char === '"') { if (quoted && line[i + 1] === '"') { value += '"'; i += 1; } else quoted = !quoted; } else if (char === "," && !quoted) { cells.push(value); value = ""; } else value += char; } cells.push(value); return cells; };
const rows = () => {
  if (!fs.existsSync(RESULTS)) return [];
  const lines = fs.readFileSync(RESULTS, "utf8").trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = parseLine(lines[0]);
  return lines.slice(1).map(parseLine).map((line) => Object.fromEntries(headers.map((key, index) => [key, line[index] || ""]))).filter((row) => CLASSES.includes(row.actualResult) && CLASSES.includes(row.aiPrediction));
};
const pct = (value) => Number.isFinite(value) ? `${(value * 100).toFixed(2)}%` : "N/A";
const analyse = (records) => {
  const matrix = Object.fromEntries(CLASSES.map((actual) => [actual, Object.fromEntries(CLASSES.map((predicted) => [predicted, 0]))]));
  records.forEach((row) => { matrix[row.actualResult][row.aiPrediction] += 1; });
  const total = records.length;
  const classes = Object.fromEntries(CLASSES.map((name) => {
    const tp = matrix[name][name]; const fp = CLASSES.reduce((sum, actual) => sum + (actual === name ? 0 : matrix[actual][name]), 0); const fn = CLASSES.reduce((sum, predicted) => sum + (predicted === name ? 0 : matrix[name][predicted]), 0);
    const precision = tp + fp ? tp / (tp + fp) : null; const recall = tp + fn ? tp / (tp + fn) : null; const f1 = precision === null || recall === null ? null : precision + recall ? 2 * precision * recall / (precision + recall) : 0;
    return [name, { actual: tp + fn, correct: tp, incorrect: fn, tp, fp, fn, tn: total - tp - fp - fn, precision, recall, f1 }];
  }));
  const average = (field) => { const values = CLASSES.map((name) => classes[name][field]).filter(Number.isFinite); return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null; };
  const correct = CLASSES.reduce((sum, name) => sum + matrix[name][name], 0); const recalls = CLASSES.map((name) => ({ name, value: classes[name].recall })).filter((item) => item.value !== null); const high = recalls.length ? Math.max(...recalls.map((item) => item.value)) : null; const low = recalls.length ? Math.min(...recalls.map((item) => item.value)) : null;
  return { matrix, classes, total, correct, accuracy: total ? correct / total : null, macro: { precision: average("precision"), recall: average("recall"), f1: average("f1") }, high: high === null ? [] : recalls.filter((item) => item.value === high).map((item) => item.name), low: low === null ? [] : recalls.filter((item) => item.value === low).map((item) => item.name), errors: CLASSES.flatMap((actual) => CLASSES.filter((predicted) => predicted !== actual).map((predicted) => ({ actual, predicted, count: matrix[actual][predicted] }))).sort((a, b) => b.count - a.count) };
};
const buildReport = (records) => {
  if (!records.length) return ["# Confusion Matrix Interpretation", "", "Status: NOT RUN YET", "", "No completed rows were found in backtest_results.csv."].join("\n");
  const result = analyse(records); const seasons = [...new Set(records.map((row) => row.season))].join(", "); const lines = ["# Premier League AI Backtesting — Confusion Matrix Interpretation", "", `Generated: ${new Date().toISOString()}`, `Seasons represented: ${seasons}`, "", "Rows are actual results; columns are Gemini predictions. TP/FP/FN/TN are one-vs-rest values for each class.", "", "## Overall", "", `- Matches evaluated: ${result.total}`, `- Correct predictions: ${result.correct}`, `- Incorrect predictions: ${result.total - result.correct}`, `- Accuracy: ${pct(result.accuracy)}`, `- Macro Precision: ${pct(result.macro.precision)}`, `- Macro Recall: ${pct(result.macro.recall)}`, `- Macro F1-score: ${pct(result.macro.f1)}`, `- Highest Recall: ${result.high.join(", ") || "N/A"}`, `- Lowest Recall: ${result.low.join(", ") || "N/A"}`, "", "## Confusion Matrix", "", "| Actual \\ Predicted | HOME | DRAW | AWAY |", "|---|---:|---:|---:|"];
  CLASSES.forEach((actual) => lines.push(`| ${actual} | ${result.matrix[actual].HOME} | ${result.matrix[actual].DRAW} | ${result.matrix[actual].AWAY} |`));
  lines.push("", "Diagonal cells are correct predictions. All other cells are misclassifications.", "", "## Per-class interpretation", "");
  CLASSES.forEach((name) => { const item = result.classes[name]; lines.push(`### ${name}`, `- Actual games: ${item.actual}`, `- Correct: ${item.correct}`, `- Incorrect: ${item.incorrect}`, `- Precision: ${pct(item.precision)}`, `- Recall: ${pct(item.recall)}`, `- F1-score: ${pct(item.f1)}`, `- One-vs-rest counts — TP: ${item.tp}, FP: ${item.fp}, FN: ${item.fn}, TN: ${item.tn}`, ""); });
  lines.push("## Observed misclassifications", ""); const errors = result.errors.filter((item) => item.count > 0); lines.push(...(errors.length ? errors.map((item) => `- Actual ${item.actual}, predicted ${item.predicted}: ${item.count}`) : ["No misclassifications were recorded."])); lines.push("", "## Notes", "", "- Metrics are calculated by JavaScript from real completed prediction rows; Gemini does not calculate evaluation metrics.", "- N/A means a denominator was zero, so the metric is not meaningful.", "- This report states counts and metrics without a qualitative claim about the AI overall."); return lines.join("\n");
};
const records = rows(); fs.mkdirSync(path.dirname(OUTPUT), { recursive: true }); fs.writeFileSync(OUTPUT, `${buildReport(records)}\n`, "utf8"); console.log(`Read ${records.length} completed prediction rows.`); console.log(`Wrote ${path.relative(ROOT, OUTPUT)}.`);
