const { execFileSync } = require("child_process");
const buildId = process.argv[2];
if (!/^[a-f0-9-]{36}$/.test(buildId || "")) throw new Error("Pass an EAS build ID.");
const state = JSON.parse(execFileSync("cmd.exe", ["/c", `npx.cmd --yes eas-cli build:view ${buildId} --json`], {
  encoding: "utf8", stdio: ["ignore", "pipe", "ignore"],
}));
(async () => {
  console.log(JSON.stringify({ status: state.status, error: state.error, artifacts: state.artifacts }));
  if (!state.logFiles?.length) return;
  const response = await fetch(state.logFiles.at(-1));
  const lines = (await response.text()).trim().split("\n");
  const events = lines.map(line => {
    try { return JSON.parse(line); } catch { return null; }
  }).filter(Boolean);
  const redact = value => String(value || "").replace(/(?:AQ\.|AIza)[A-Za-z0-9._-]+/g, "[redacted]");
  console.log(JSON.stringify({ recentEvents: events.slice(-5).map(event => ({ phase: event.phase, level: event.level, message: redact(event.msg || event.message) })) }));
})().catch(error => { console.error(error.message); process.exitCode = 1; });
