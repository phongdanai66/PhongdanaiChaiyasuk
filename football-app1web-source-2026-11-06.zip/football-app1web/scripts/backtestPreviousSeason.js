/*
 * Backtest the match model using only last season's Premier League results.
 * Each fixture is predicted from results strictly before its kick-off, so it
 * never learns the answer it is being scored against.
 */
const seasonData = require("../data/premierLeagueSeason.json");

const matches = (seasonData.previousSeasonMatches || [])
  .filter(
    (match) =>
      match.status === "FINISHED" &&
      Number.isFinite(match.score?.fullTime?.home) &&
      Number.isFinite(match.score?.fullTime?.away)
  )
  .sort((a, b) => Date.parse(a.utcDate) - Date.parse(b.utcDate));

const poisson = (goals, expectedGoals) => {
  let factorial = 1;
  for (let number = 2; number <= goals; number += 1) factorial *= number;
  return (Math.exp(-expectedGoals) * expectedGoals ** goals) / factorial;
};

const venueStats = (history, teamId, venue, maxHistory, recencyDecay) => {
  const teamMatches = history
    .filter((match) =>
      venue === "home"
        ? match.homeTeam?.id === teamId
        : match.awayTeam?.id === teamId
    )
    .sort((a, b) => Date.parse(b.utcDate) - Date.parse(a.utcDate))
    .slice(0, maxHistory);

  return teamMatches.reduce(
    (stats, match, index) => {
      const weight = recencyDecay ** index;
      const isHome = venue === "home";
      stats.games += weight;
      stats.goalsFor += weight * (isHome ? match.score.fullTime.home : match.score.fullTime.away);
      stats.goalsAgainst += weight * (isHome ? match.score.fullTime.away : match.score.fullTime.home);
      return stats;
    },
    { games: 0, goalsFor: 0, goalsAgainst: 0 }
  );
};

const predict = (history, fixture, settings) => {
  const totals = history.reduce(
    (value, match) => ({
      home: value.home + match.score.fullTime.home,
      away: value.away + match.score.fullTime.away,
    }),
    { home: 0, away: 0 }
  );
  const leagueHome = history.length ? totals.home / history.length : 1.5;
  const leagueAway = history.length ? totals.away / history.length : 1.2;
  const home = venueStats(history, fixture.homeTeam.id, "home", settings.maxHistory, settings.recencyDecay);
  const away = venueStats(history, fixture.awayTeam.id, "away", settings.maxHistory, settings.recencyDecay);
  const smooth = (goals, games, average) =>
    (goals + settings.priorGames * average) / (games + settings.priorGames);
  const expectedHome = Math.min(3.5, Math.max(0.25,
    leagueHome * (smooth(home.goalsFor, home.games, leagueHome) / leagueHome) *
      (smooth(away.goalsAgainst, away.games, leagueHome) / leagueHome)
  ));
  const expectedAway = Math.min(3.5, Math.max(0.25,
    leagueAway * (smooth(away.goalsFor, away.games, leagueAway) / leagueAway) *
      (smooth(home.goalsAgainst, home.games, leagueAway) / leagueAway)
  ));
  const probabilities = [0, 0, 0]; // home, draw, away
  for (let homeGoals = 0; homeGoals <= 7; homeGoals += 1) {
    for (let awayGoals = 0; awayGoals <= 7; awayGoals += 1) {
      const probability = poisson(homeGoals, expectedHome) * poisson(awayGoals, expectedAway);
      probabilities[homeGoals > awayGoals ? 0 : homeGoals === awayGoals ? 1 : 2] += probability;
    }
  }
  const total = probabilities.reduce((sum, value) => sum + value, 0);
  return probabilities.map((value) => value / total);
};

const outcomeIndex = (match) =>
  match.score.fullTime.home > match.score.fullTime.away
    ? 0
    : match.score.fullTime.home === match.score.fullTime.away
      ? 1
      : 2;

const evaluate = (settings) => {
  let correct = 0;
  let brierScore = 0;
  let logLoss = 0;
  for (const fixture of matches) {
    const history = matches.filter((match) => Date.parse(match.utcDate) < Date.parse(fixture.utcDate));
    const probabilities = predict(history, fixture, settings);
    const actual = outcomeIndex(fixture);
    const predicted = probabilities.indexOf(Math.max(...probabilities));
    correct += Number(predicted === actual);
    brierScore += probabilities.reduce(
      (sum, probability, index) => sum + (probability - Number(index === actual)) ** 2,
      0
    );
    logLoss -= Math.log(Math.max(probabilities[actual], 1e-12));
  }
  return {
    ...settings,
    accuracy: correct / matches.length,
    brier: brierScore / matches.length,
    logLoss: logLoss / matches.length,
  };
};

const candidates = [];
for (const priorGames of [3, 5, 8, 10]) {
  for (const recencyDecay of [0.82, 0.9, 0.96]) {
    for (const maxHistory of [5, 10]) {
      candidates.push(evaluate({ priorGames, recencyDecay, maxHistory }));
    }
  }
}

candidates.sort((a, b) => a.brier - b.brier || a.logLoss - b.logLoss);
const best = candidates[0];
console.log("Previous-season backtest (380 fixtures, no future results used)");
console.log(`Best settings: priorGames=${best.priorGames}, recencyDecay=${best.recencyDecay}, maxHistory=${best.maxHistory}`);
console.log(`Accuracy: ${(best.accuracy * 100).toFixed(1)}% | Brier score: ${best.brier.toFixed(3)} | Log loss: ${best.logLoss.toFixed(3)}`);
console.log("Top 5 configurations:");
for (const result of candidates.slice(0, 5)) {
  console.log(`  prior=${result.priorGames}, decay=${result.recencyDecay}, history=${result.maxHistory}: ${(result.accuracy * 100).toFixed(1)}%, Brier ${result.brier.toFixed(3)}`);
}
