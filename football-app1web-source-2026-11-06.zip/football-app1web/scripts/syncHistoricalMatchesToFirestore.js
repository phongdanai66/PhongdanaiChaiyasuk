const fs = require("fs");
const path = require("path");

const PROJECT_ID = "match-bb30c";
const DATABASE_ID = "(default)";
const COLLECTION = "historicalSeasons";
const PROJECT_ROOT = path.resolve(__dirname, "..");
const DATA_PATH = path.join(PROJECT_ROOT, "data", "premierLeagueSeason.json");
const BATCH_SIZE = 400;
const HISTORICAL_SEASON_COUNT = 5;
const FIREBASE_SCOPES = [
  "email", "openid", "https://www.googleapis.com/auth/cloudplatformprojects.readonly",
  "https://www.googleapis.com/auth/firebase", "https://www.googleapis.com/auth/cloud-platform",
];

const getFirebaseToolsAuth = () => {
  const configuredPath = process.env.FIREBASE_TOOLS_AUTH_PATH;
  const windowsGlobalPath = process.env.APPDATA
    ? path.join(process.env.APPDATA, "npm", "node_modules", "firebase-tools", "lib", "auth.js")
    : "";
  const authPath = configuredPath || windowsGlobalPath;
  if (!authPath || !fs.existsSync(authPath)) {
    throw new Error("Firebase CLI is not installed. Run firebase login first.");
  }
  return require(authPath);
};

const getAccessToken = async () => {
  const auth = getFirebaseToolsAuth();
  const account = auth.getGlobalDefaultAccount();
  if (!account?.tokens?.refresh_token) {
    throw new Error("Firebase login is required. Run firebase login --reauth.");
  }
  const tokens = await auth.getAccessToken(account.tokens.refresh_token, FIREBASE_SCOPES);
  if (!tokens?.access_token) throw new Error("Unable to obtain a Firebase access token.");
  return tokens.access_token;
};

const encodeValue = (value) => {
  if (value === null || value === undefined) return { nullValue: null };
  if (typeof value === "boolean") return { booleanValue: value };
  if (typeof value === "number") {
    return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
  }
  if (typeof value === "string") return { stringValue: value };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(encodeValue) } };
  return {
    mapValue: {
      fields: Object.fromEntries(Object.entries(value).map(([key, nestedValue]) => [key, encodeValue(nestedValue)])),
    },
  };
};

const encodeFields = (document) =>
  Object.fromEntries(Object.entries(document).map(([key, value]) => [key, encodeValue(value)]));

const seasonDocumentId = (startYear) => `${startYear}-${String(startYear + 1).slice(-2)}`;

const writeBatch = async (token, documentRoot, writes) => {
  const response = await fetch(`https://firestore.googleapis.com/v1/${documentRoot}:batchWrite`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ writes }),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(result?.error?.message || `Firestore upload failed: ${response.status}`);
  }
  const failedWrites = (result.status ?? []).filter((status) => status && Object.keys(status).length > 0);
  if ((result.writeResults?.length ?? 0) !== writes.length || failedWrites.length) {
    throw new Error(`Firestore wrote ${result.writeResults?.length ?? 0}/${writes.length} documents.`);
  }
};

const getHistoricalSeasons = (data) => {
  const seasons = data.historicalSeasonMatches ?? [];
  if (seasons.length !== HISTORICAL_SEASON_COUNT) {
    throw new Error(`Expected ${HISTORICAL_SEASON_COUNT} historical seasons, found ${seasons.length}.`);
  }

  const currentSeason = Number(data.season?.startYear);
  if (!Number.isInteger(currentSeason)) throw new Error("Invalid current season start year.");
  const expectedStartYears = new Set(
    Array.from({ length: HISTORICAL_SEASON_COUNT }, (_, index) => currentSeason - index - 1)
  );
  for (const season of seasons) {
    const startYear = Number(season.startYear);
    const matchYears = new Set((season.matches ?? []).map((match) => Number(match?.season?.startYear)));
    if (!expectedStartYears.has(startYear) || season.matches?.length !== 380 || matchYears.size !== 1 || !matchYears.has(startYear)) {
      throw new Error(`Invalid data for historical season ${season.seasonLabel ?? startYear}.`);
    }
    expectedStartYears.delete(startYear);
  }
  return seasons;
};

const syncHistoricalMatches = async () => {
  const data = JSON.parse(fs.readFileSync(DATA_PATH, "utf8"));
  const seasons = getHistoricalSeasons(data);
  const token = await getAccessToken();
  const documentRoot = `projects/${PROJECT_ID}/databases/${DATABASE_ID}/documents`;
  const writes = seasons.flatMap((season) => {
    const seasonId = seasonDocumentId(Number(season.startYear));
    const seasonPath = `${documentRoot}/${COLLECTION}/${seasonId}`;
    const seasonMetadata = {
      update: {
        name: seasonPath,
        fields: encodeFields({
          seasonLabel: season.seasonLabel,
          startYear: Number(season.startYear),
          matchCount: season.matches.length,
          syncedAt: data.syncedAt,
        }),
      },
    };
    const matches = season.matches.map((match) => ({
      update: {
        name: `${seasonPath}/matches/${match.id}`,
        fields: encodeFields({ ...match, seasonLabel: season.seasonLabel }),
      },
    }));
    return [seasonMetadata, ...matches];
  });

  for (let index = 0; index < writes.length; index += BATCH_SIZE) {
    await writeBatch(token, documentRoot, writes.slice(index, index + BATCH_SIZE));
  }

  console.log(JSON.stringify({
    projectId: PROJECT_ID,
    collection: COLLECTION,
    seasons: seasons.map((season) => ({ season: season.seasonLabel, matches: season.matches.length })),
    totalDocuments: writes.length,
  }, null, 2));
};

syncHistoricalMatches().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
