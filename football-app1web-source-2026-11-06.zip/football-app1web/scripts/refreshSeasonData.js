const fs = require("fs");
const path = require("path");

const FOOTBALL_DATA_BASE_URL = "https://api.football-data.org/v4";
const PROJECT_ROOT = path.resolve(__dirname, "..");
const OUTPUT_PATH = path.join(PROJECT_ROOT, "data", "premierLeagueSeason.json");
// The prior season plus three additional completed seasons for the AI model.
const HISTORICAL_SEASON_COUNT = 5;
const HISTORICAL_CSV_BASE_URL = "https://football-data.co.uk/mmz4281";

const CSV_TEAM_ALIASES = {
  "man city": "manchester city",
  "man united": "manchester united",
  "nott'm forest": "nottingham forest",
  "nottm forest": "nottingham forest",
  spurs: "tottenham",
  wolves: "wolverhampton wanderers",
};

const getArgValue = (name) => {
  const prefix = `--${name}=`;
  const arg = process.argv.find((value) => value.startsWith(prefix));
  return arg ? arg.slice(prefix.length) : "";
};

const readLocalEnv = () => {
  const envPath = path.join(PROJECT_ROOT, ".env.local");

  if (!fs.existsSync(envPath)) {
    return {};
  }

  return Object.fromEntries(
    fs
      .readFileSync(envPath, "utf8")
      .split(/\r?\n/)
      .filter((line) => line && !line.trim().startsWith("#") && line.includes("="))
      .map((line) => {
        const separator = line.indexOf("=");
        const key = line.slice(0, separator).trim();
        const value = line
          .slice(separator + 1)
          .trim()
          .replace(/^(["'])(.*)\1$/, "$2");
        return [key, value];
      })
  );
};

const getCurrentSeasonStartYear = () => {
  const now = new Date();
  return now.getUTCMonth() >= 6 ? now.getUTCFullYear() : now.getUTCFullYear() - 1;
};

const requestFootballData = async (token, route, season) => {
  const response = await fetch(
    `${FOOTBALL_DATA_BASE_URL}${route}?season=${encodeURIComponent(season)}`,
    { headers: { "X-Auth-Token": token } }
  );
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      data?.message || `football-data.org request failed with status ${response.status}`
    );
  }

  return data;
};

const normalizeSeason = (season, startYear) => ({
  id: season?.id ?? "",
  startDate: season?.startDate ?? `${startYear}-08-01`,
  endDate: season?.endDate ?? `${startYear + 1}-05-31`,
  currentMatchday: season?.currentMatchday ?? "",
  startYear,
});

const normalizeTeam = (team = {}) => ({
  id: team.id ?? "",
  name: team.name ?? "",
  shortName: team.shortName ?? "",
  tla: team.tla ?? "",
  crest: team.crest ?? "",
});

const normalizeTeamKey = (name = "") => {
  const normalized = name.trim().toLowerCase();
  return CSV_TEAM_ALIASES[normalized] || normalized;
};

const parseCsvLine = (line) => {
  const cells = [];
  let value = "";
  let quoted = false;

  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') {
        value += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === "," && !quoted) {
      cells.push(value);
      value = "";
    } else {
      value += character;
    }
  }
  cells.push(value);
  return cells;
};

const parseCsvDate = (dateText, timeText = "12:00") => {
  const [day, month, shortYear] = (dateText || "").split("/");
  const year = Number(shortYear) < 100 ? 2000 + Number(shortYear) : Number(shortYear);
  const time = /^\d{1,2}:\d{2}$/.test(timeText) ? timeText.padStart(5, "0") : "12:00";
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}T${time}:00Z`;
};

const buildTeamLookup = (teams = []) => {
  const lookup = new Map();
  teams.forEach((team) => {
    [team.name, team.shortName, team.tla].filter(Boolean).forEach((name) => {
      lookup.set(normalizeTeamKey(name), normalizeTeam(team));
    });
  });
  return lookup;
};

const getCsvTeam = (name, teamLookup) =>
  teamLookup.get(normalizeTeamKey(name)) || {
    id: `historical-${normalizeTeamKey(name).replace(/[^a-z0-9]/g, "-")}`,
    name,
    shortName: name,
    tla: "",
    crest: "",
  };

const requestHistoricalCsv = async (startYear, teamLookup, syncedAt) => {
  const seasonCode = `${String(startYear).slice(-2)}${String(startYear + 1).slice(-2)}`;
  const response = await fetch(`${HISTORICAL_CSV_BASE_URL}/${seasonCode}/E0.csv`);
  if (!response.ok) {
    throw new Error(`Historical CSV request failed with status ${response.status}`);
  }

  const [headerLine, ...rows] = (await response.text()).replace(/^\uFEFF/, "").trim().split(/\r?\n/);
  const headers = parseCsvLine(headerLine);
  const column = Object.fromEntries(headers.map((header, index) => [header, index]));
  const season = normalizeSeason(null, startYear);

  return rows
    .map(parseCsvLine)
    .filter((row) => row[column.HomeTeam] && row[column.AwayTeam] && row[column.FTHG] !== "" && row[column.FTAG] !== "")
    .map((row, index) => ({
      id: `csv-pl-${startYear}-${index + 1}`,
      utcDate: parseCsvDate(row[column.Date], row[column.Time]),
      status: "FINISHED",
      matchday: null,
      stage: "REGULAR_SEASON",
      competition: { code: "PL", name: "Premier League" },
      season,
      homeTeam: getCsvTeam(row[column.HomeTeam], teamLookup),
      awayTeam: getCsvTeam(row[column.AwayTeam], teamLookup),
      score: {
        fullTime: { home: Number(row[column.FTHG]), away: Number(row[column.FTAG]) },
      },
      lastSyncedAt: syncedAt,
    }));
};

const normalizeMatch = (match, season, startYear, syncedAt) => ({
  id: match?.id ?? "",
  utcDate: match?.utcDate ?? "",
  status: match?.status ?? "",
  matchday: match?.matchday ?? null,
  stage: match?.stage ?? "",
  competition: match?.competition ?? null,
  season: normalizeSeason(match?.season ?? season, startYear),
  homeTeam: normalizeTeam(match?.homeTeam),
  awayTeam: normalizeTeam(match?.awayTeam),
  score: match?.score ?? {},
  lastSyncedAt: syncedAt,
});

const refreshSeasonData = async () => {
  const localEnv = readLocalEnv();
  const token =
    process.env.FOOTBALL_DATA_API_TOKEN ||
    process.env.EXPO_PUBLIC_FOOTBALL_DATA_API_TOKEN ||
    localEnv.EXPO_PUBLIC_FOOTBALL_DATA_API_TOKEN;
  const startYear = Number(
    process.env.FOOTBALL_DATA_SEASON ||
      getArgValue("season") ||
      getCurrentSeasonStartYear()
  );

  if (!token) {
    throw new Error("Missing EXPO_PUBLIC_FOOTBALL_DATA_API_TOKEN");
  }

  if (!Number.isInteger(startYear)) {
    throw new Error("Season must be a four-digit start year, for example 2026");
  }

  const historicalStartYears = Array.from(
    { length: HISTORICAL_SEASON_COUNT },
    (_, index) => startYear - index - 1
  );
  const syncedAt = new Date().toISOString();
  const [matchesData, standingsData, teamsData] = await Promise.all([
      requestFootballData(token, "/competitions/PL/matches", startYear),
      requestFootballData(token, "/competitions/PL/standings", startYear),
      requestFootballData(token, "/competitions/PL/teams", startYear),
    ]);
  const totalStanding =
    standingsData?.standings?.find((standing) => standing?.type === "TOTAL") ??
    standingsData?.standings?.[0];
  const season = normalizeSeason(
    standingsData?.season ?? matchesData?.matches?.[0]?.season,
    startYear
  );
  const matches = matchesData?.matches ?? [];
  const standings = totalStanding?.table ?? [];
  const teams = teamsData?.teams ?? [];
  const teamLookup = buildTeamLookup(teams);
  const historicalSeasonMatches = await Promise.all(historicalStartYears.map(async (historicalStartYear) => {
    let matchesForSeason;
    let sourceSeason;

    try {
      const data = await requestFootballData(
        token,
        "/competitions/PL/matches",
        historicalStartYear
      );
      sourceSeason = data?.season ?? data?.matches?.[0]?.season;
      matchesForSeason = (data?.matches ?? []).map((match) =>
        normalizeMatch(match, sourceSeason, historicalStartYear, syncedAt)
      );
    } catch (error) {
      console.warn(
        `football-data.org cannot provide ${historicalStartYear}/${String(historicalStartYear + 1).slice(-2)}; using public historical results.`
      );
      matchesForSeason = await requestHistoricalCsv(
        historicalStartYear,
        teamLookup,
        syncedAt
      );
    }

    return {
      startYear: historicalStartYear,
      seasonLabel: `${historicalStartYear}/${String(historicalStartYear + 1).slice(-2)}`,
      matches: matchesForSeason,
    };
  }));
  const previousSeasonStartYear = historicalStartYears[0];
  const previousMatches = historicalSeasonMatches[0]?.matches ?? [];

  if (
    matches.length !== 380 ||
    standings.length !== 20 ||
    teams.length !== 20 ||
    historicalSeasonMatches.some((season) => season.matches.length !== 380)
  ) {
    throw new Error(
      `Unexpected Premier League data: ${matches.length} current matches, ${historicalSeasonMatches.map((season) => season.matches.length).join(", ")} historical matches, ${standings.length} standings, and ${teams.length} squads`
    );
  }

  const output = {
    competitionCode: "PL",
    season,
    seasonLabel: `${startYear}/${String(startYear + 1).slice(-2)}`,
    previousSeasonLabel: `${previousSeasonStartYear}/${String(startYear).slice(-2)}`,
    syncedAt,
    matches: matches.map((match) =>
      normalizeMatch(match, season, startYear, syncedAt)
    ),
    previousSeasonMatches: previousMatches.map((match) =>
      ({ ...match, lastSyncedAt: syncedAt })
    ),
    historicalSeasonMatches,
    standings: standings.map((standing) => ({
      id: standing?.team?.id ?? String(standing?.position ?? ""),
      position: standing?.position ?? 0,
      playedGames: standing?.playedGames ?? 0,
      won: standing?.won ?? 0,
      draw: standing?.draw ?? 0,
      lost: standing?.lost ?? 0,
      points: standing?.points ?? 0,
      goalsFor: standing?.goalsFor ?? 0,
      goalsAgainst: standing?.goalsAgainst ?? 0,
      goalDifference: standing?.goalDifference ?? 0,
      team: normalizeTeam(standing?.team),
      season,
      lastSyncedAt: syncedAt,
    })),
    teams: teams.map((team) => ({
      ...normalizeTeam(team),
      squad: (team?.squad ?? [])
        .filter((player) => player?.name)
        .map((player) => ({
          id: player?.id ?? "",
          name: player.name,
          position: player?.position ?? "-",
          dateOfBirth: player?.dateOfBirth ?? "",
          nationality: player?.nationality ?? "",
          shirtNumber: player?.shirtNumber ?? null,
        })),
    })),
  };

  fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
  fs.writeFileSync(OUTPUT_PATH, `${JSON.stringify(output, null, 2)}\n`, "utf8");
  console.log(
    `Updated Premier League ${output.seasonLabel}: ${output.matches.length} current matches, ${output.historicalSeasonMatches.reduce((total, season) => total + season.matches.length, 0)} historical matches across ${output.historicalSeasonMatches.length} seasons for AI, ${output.standings.length} teams, ${output.teams.reduce((total, team) => total + team.squad.length, 0)} players`
  );
};

refreshSeasonData().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
