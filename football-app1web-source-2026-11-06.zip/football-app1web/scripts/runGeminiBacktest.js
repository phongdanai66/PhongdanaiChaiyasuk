/*
 * Standalone backtest runner. This script does not import or change app UI.
 * Usage:
 *   node scripts/runGeminiBacktest.js                 # inspect available fixtures only
 *   node scripts/runGeminiBacktest.js --run --limit=10
 *   node scripts/runGeminiBacktest.js --run           # all configured seasons
 */
const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const DATA_PATH = path.join(ROOT, "data", "premierLeagueSeason.json");
const OUTPUT_DIR = path.join(ROOT, "backtesting", "results");
const RAW_PATH = path.join(OUTPUT_DIR, "ai_predictions.json");
const SEASONS = [2023, 2024, 2025];
const OUTCOMES = ["HOME", "DRAW", "AWAY"];
const GEMINI_MODEL = "gemini-3.8-flash";
const GEMINI_INTERACTIONS_URL = "https://generativelanguage.googleapis.com/v1beta/interactions";
const getArg = (name) => { const item = process.argv.find((arg) => arg.startsWith(`--${name}=`)); return item ? item.split("=", 2)[1] : ""; };
const shouldRun = process.argv.includes("--run");
const selectedSeason = Number(getArg("season"));
const purgeSeason = Number(getArg("purge-season"));
const limit = Number(getArg("limit")) || Infinity;
const delayMs = Math.max(250, Number(getArg("delayMs")) || 1000);
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const isQuotaExceeded = (error) => /quota exceeded|requestsperdayperproject|generate_requests_free_tier_requests/i.test(`${error?.status || ""} ${error?.message || ""}`);

const localEnv = () => {
  const envPath = path.join(ROOT, ".env.local");
  if (!fs.existsSync(envPath)) return {};
  return Object.fromEntries(fs.readFileSync(envPath, "utf8").split(/\r?\n/).filter((line) => line.includes("=") && !line.trim().startsWith("#")).map((line) => { const index = line.indexOf("="); return [line.slice(0, index).trim(), line.slice(index + 1).trim().replace(/^("|')|("|')$/g, "")]; }));
};
// Keep the backtest credential private. EXPO_PUBLIC_* values are embedded in web builds.
const key = process.env.BACKTEST_GEMINI_API_KEY || localEnv().BACKTEST_GEMINI_API_KEY || process.env.EXPO_PUBLIC_GEMINI_API_KEY || localEnv().EXPO_PUBLIC_GEMINI_API_KEY;
const date = (match) => Date.parse(match.utcDate || "");
const outcome = (match) => {
  const home = match.score?.fullTime?.home; const away = match.score?.fullTime?.away;
  if (!Number.isFinite(home) || !Number.isFinite(away)) return null;
  return home === away ? "DRAW" : home > away ? "HOME" : "AWAY";
};
const finished = (match) => match.status === "FINISHED" && Number.isFinite(date(match)) && outcome(match);
const label = (year) => `${year}/${String(year + 1).slice(-2)}`;
const csvCell = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
const csv = (headers, rows) => [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\n");

const getData = () => {
  const data = JSON.parse(fs.readFileSync(DATA_PATH, "utf8"));
  return [data.matches || [], ...(data.historicalSeasonMatches || []).map((item) => item.matches || []), data.previousSeasonMatches || []]
    .flat().filter((match, index, all) => match.id && all.findIndex((item) => String(item.id) === String(match.id)) === index);
};
const stats = (history, teamId, venue) => {
  const games = history.filter((match) => venue === "HOME" ? String(match.homeTeam?.id) === String(teamId) : String(match.awayTeam?.id) === String(teamId));
  const totals = games.reduce((value, match) => {
    const home = String(match.homeTeam?.id) === String(teamId);
    value.played += 1; value.goalsFor += home ? match.score.fullTime.home : match.score.fullTime.away; value.goalsAgainst += home ? match.score.fullTime.away : match.score.fullTime.home;
    const result = outcome(match); value.points += result === "DRAW" ? 1 : (result === "HOME") === home ? 3 : 0; return value;
  }, { played: 0, points: 0, goalsFor: 0, goalsAgainst: 0 });
  const form = history.filter((match) => String(match.homeTeam?.id) === String(teamId) || String(match.awayTeam?.id) === String(teamId)).sort((a, b) => date(b) - date(a)).slice(0, 5).map((match) => ({ date: match.utcDate, opponent: String(match.homeTeam?.id) === String(teamId) ? match.awayTeam?.name : match.homeTeam?.name, score: `${match.score.fullTime.home}-${match.score.fullTime.away}`, result: outcome(match) }));
  return { ...totals, goalDifference: totals.goalsFor - totals.goalsAgainst, lastFive: form };
};
const snapshot = (fixture, matches) => {
  const kickoff = date(fixture);
  const history = matches.filter((match) => finished(match) && date(match) < kickoff);
  const h2h = history.filter((match) => (String(match.homeTeam?.id) === String(fixture.homeTeam?.id) && String(match.awayTeam?.id) === String(fixture.awayTeam?.id)) || (String(match.homeTeam?.id) === String(fixture.awayTeam?.id) && String(match.awayTeam?.id) === String(fixture.homeTeam?.id))).sort((a, b) => date(b) - date(a)).slice(0, 5).map((match) => ({ date: match.utcDate, home: match.homeTeam?.name, away: match.awayTeam?.name, score: `${match.score.fullTime.home}-${match.score.fullTime.away}` }));
  return { kickoff: fixture.utcDate, dataCutoff: new Date(kickoff - 1).toISOString(), homeTeam: { name: fixture.homeTeam?.name, homeStats: stats(history, fixture.homeTeam?.id, "HOME") }, awayTeam: { name: fixture.awayTeam?.name, awayStats: stats(history, fixture.awayTeam?.id, "AWAY") }, headToHeadBeforeKickoff: h2h, historicalMatchesUsed: history.length };
};
const parsePrediction = (text) => {
  const clean = text.replace(/```(?:json)?/gi, "").replace(/```/g, ""); const start = clean.indexOf("{"); const end = clean.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("Gemini returned no JSON object.");
  const value = JSON.parse(clean.slice(start, end + 1)); const probabilities = [Number(value.homeWinProbability), Number(value.drawProbability), Number(value.awayWinProbability)]; const sum = probabilities.reduce((a, b) => a + b, 0);
  if (!OUTCOMES.includes(value.prediction) || probabilities.some((p) => !Number.isFinite(p) || p < 0 || p > 1) || sum < .99 || sum > 1.01) throw new Error("Invalid Gemini prediction JSON.");
  return { prediction: value.prediction, homeWinProbability: probabilities[0] / sum, drawProbability: probabilities[1] / sum, awayWinProbability: probabilities[2] / sum };
};
const getInteractionText = (interaction) => {
  const step = [...(interaction?.steps || [])].reverse().find((item) => item?.type === "model_output");
  const text = (step?.content || []).filter((item) => item?.type === "text").map((item) => item.text || "").join("").trim();
  if (!text) throw new Error("Gemini returned no text output.");
  return text;
};
const predict = async (preMatchData) => {
  const prompt = `You are predicting a football match using only information available before the match started. Do not use the actual result or any information that occurred after kickoff. Return ONLY valid JSON: {"prediction":"HOME","homeWinProbability":0.55,"drawProbability":0.25,"awayWinProbability":0.20}. prediction must be HOME, DRAW, or AWAY. Probabilities must be 0..1 and sum to 1. Pre-match data:\n${JSON.stringify(preMatchData)}`;
  let lastError;
  for (let attempt = 0; attempt < 4; attempt += 1) { try {
    const response = await Promise.race([
      fetch(GEMINI_INTERACTIONS_URL, { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key }, body: JSON.stringify({ model: GEMINI_MODEL, input: prompt }) }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Gemini request timed out.")), 45000)),
    ]);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(payload?.error?.message || `Gemini request failed (${response.status}).`); error.status = response.status; throw error; }
    return parsePrediction(getInteractionText(payload));
  } catch (error) { lastError = error; if (!/\b(408|429|500|502|503|504)\b|unavailable|resource exhausted/i.test(`${error.status || ""} ${error.message || ""}`) || attempt === 3) break; await wait(1000 * 2 ** attempt); } }
  throw lastError;
};
const emptyMatrix = () => Object.fromEntries(OUTCOMES.map((actual) => [actual, Object.fromEntries(OUTCOMES.map((predicted) => [predicted, 0]))]));
const evaluate = (records) => {
  const done = records.filter((record) => record.status === "COMPLETE"); const matrix = emptyMatrix(); done.forEach((record) => { matrix[record.actualResult][record.prediction] += 1; });
  const classes = Object.fromEntries(OUTCOMES.map((item) => { const tp = matrix[item][item]; const predicted = OUTCOMES.reduce((n, actual) => n + matrix[actual][item], 0); const actual = OUTCOMES.reduce((n, prediction) => n + matrix[item][prediction], 0); const precision = predicted ? tp / predicted : null; const recall = actual ? tp / actual : null; return [item, { precision, recall, f1: precision === null || recall === null ? null : precision + recall ? 2 * precision * recall / (precision + recall) : 0 }]; }));
  const correct = OUTCOMES.reduce((n, item) => n + matrix[item][item], 0); const average = (field) => { const values = OUTCOMES.map((item) => classes[item][field]).filter(Number.isFinite); return values.length ? values.reduce((a, b) => a + b, 0) / values.length : null; };
  return { totalMatches: done.length, correct, incorrect: done.length - correct, accuracy: done.length ? correct / done.length : null, classes, macro: { precision: average("precision"), recall: average("recall"), f1: average("f1") }, matrix };
};
const writeOutputs = (records) => {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true }); fs.writeFileSync(RAW_PATH, `${JSON.stringify(records, null, 2)}\n`);
  const complete = records.filter((record) => record.status === "COMPLETE");
  fs.writeFileSync(path.join(OUTPUT_DIR, "backtest_results.csv"), `${csv(["season","matchId","date","homeTeam","awayTeam","homeScore","awayScore","aiPrediction","homeProbability","drawProbability","awayProbability","actualResult","correct"], complete.map((r) => [r.season,r.matchId,r.kickoff,r.homeTeam,r.awayTeam,r.homeScore,r.awayScore,r.prediction,r.homeWinProbability,r.drawProbability,r.awayWinProbability,r.actualResult,r.correct]))}\n`);
  const metricsRows = SEASONS.filter((year) => records.some((r) => r.season === label(year))).map((year) => [label(year), evaluate(records.filter((r) => r.season === label(year)))]); if (metricsRows.length) metricsRows.push(["ALL", evaluate(records)]);
  fs.writeFileSync(path.join(OUTPUT_DIR, "evaluation_summary.csv"), `${csv(["season","totalMatches","correct","incorrect","accuracy","homePrecision","homeRecall","homeF1","drawPrecision","drawRecall","drawF1","awayPrecision","awayRecall","awayF1","macroPrecision","macroRecall","macroF1"], metricsRows.map(([season,m]) => [season,m.totalMatches,m.correct,m.incorrect,m.accuracy,m.classes.HOME.precision,m.classes.HOME.recall,m.classes.HOME.f1,m.classes.DRAW.precision,m.classes.DRAW.recall,m.classes.DRAW.f1,m.classes.AWAY.precision,m.classes.AWAY.recall,m.classes.AWAY.f1,m.macro.precision,m.macro.recall,m.macro.f1]))}\n`);
  const matrixRows = [];
  metricsRows.forEach(([season, metric]) => {
    OUTCOMES.forEach((actual) => OUTCOMES.forEach((predicted) => {
      matrixRows.push([season, actual, predicted, metric.matrix[actual][predicted]]);
    }));
  });
  fs.writeFileSync(path.join(OUTPUT_DIR, "confusion_matrix.csv"), `${csv(["season","actual","predicted","count"], matrixRows)}\n`);
};

(async () => {
  const matches = getData(); const seasons = selectedSeason ? [selectedSeason] : SEASONS; const fixtures = matches.filter((match) => seasons.includes(Number(match.season?.startYear)) && finished(match)).sort((a, b) => date(a) - date(b));
  if (fixtures.length !== seasons.length * 380) throw new Error(`Expected ${seasons.length * 380} finished fixtures but found ${fixtures.length}. Refresh season data before running.`);
  console.log(`Prepared ${fixtures.length} fixtures for ${seasons.map(label).join(", ")}.`);
  if (purgeSeason) {
    const existing = fs.existsSync(RAW_PATH) ? JSON.parse(fs.readFileSync(RAW_PATH, "utf8")) : [];
    const target = label(purgeSeason);
    const retained = existing.filter((record) => record.season !== target);
    if (retained.length === existing.length) throw new Error(`No stored records found for ${target}.`);
    writeOutputs(retained);
    console.log(`Removed ${existing.length - retained.length} stored records for ${target}.`);
    return;
  }
  if (!shouldRun) { console.log("Dry run only. Add --run to call Gemini. Example: node scripts/runGeminiBacktest.js --run --limit=10"); return; }
  if (!key) throw new Error("Missing EXPO_PUBLIC_GEMINI_API_KEY in .env.local.");
  const existing = fs.existsSync(RAW_PATH) ? JSON.parse(fs.readFileSync(RAW_PATH, "utf8")) : []; const cache = new Map(existing.filter((r) => r.status === "COMPLETE").map((r) => [`${r.season}:${r.matchId}`, r]));
  let attempted = 0;
  for (const fixture of fixtures) { if (attempted >= limit) break; const season = label(Number(fixture.season.startYear)); const id = `${season}:${fixture.id}`; if (cache.has(id)) continue; const base = { season, matchId: String(fixture.id), kickoff: fixture.utcDate, homeTeam: fixture.homeTeam?.name, awayTeam: fixture.awayTeam?.name, homeScore: fixture.score.fullTime.home, awayScore: fixture.score.fullTime.away, actualResult: outcome(fixture), predictionCreatedAt: new Date().toISOString() }; try { const preMatchData = snapshot(fixture, matches); const result = await predict(preMatchData); existing.push({ ...base, ...result, model: GEMINI_MODEL, dataCutoff: preMatchData.dataCutoff, promptVersion: "backtest-json-v1", correct: result.prediction === base.actualResult, status: "COMPLETE" }); console.log(`SUCCESS ${season} ${base.homeTeam} vs ${base.awayTeam}`); } catch (error) { if (isQuotaExceeded(error)) { writeOutputs(existing); console.log("Stopped: Gemini quota exceeded. No additional error records were saved."); break; } existing.push({ ...base, status: "ERROR", errorMessage: error.message || "Prediction failed." }); console.log(`ERROR ${season} ${base.homeTeam} vs ${base.awayTeam}: ${error.message || "Prediction failed."}`); } attempted += 1; writeOutputs(existing); await wait(delayMs); }
  writeOutputs(existing); console.log(`Finished. Results written to ${path.relative(ROOT, OUTPUT_DIR)}.`);
})().catch((error) => { console.error(error.message || error); process.exit(1); });
