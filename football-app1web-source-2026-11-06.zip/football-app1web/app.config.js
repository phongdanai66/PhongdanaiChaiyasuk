const { expo } = require("./app.json");

const isAndroidBuild = process.env.EAS_BUILD_PLATFORM === "android";
const geminiApiKey = isAndroidBuild
  ? process.env.EXPO_PUBLIC_GEMINI_API_KEY_MOBILE ||
    process.env.EXPO_PUBLIC_GEMINI_API_KEY
  : process.env.EXPO_PUBLIC_GEMINI_API_KEY_WEB ||
    process.env.EXPO_PUBLIC_GEMINI_API_KEY;

// The direct, no-billing Gemini integration needs the key in the client
// bundle. Read it from the local environment at build time so no key is ever
// committed in source code.
module.exports = () => ({
  ...expo,
  extra: {
    ...expo.extra,
    // This key is bundled into the app, so it must be a client-restricted,
    // public key rather than a server or backtesting credential.
    geminiApiKey: geminiApiKey || "",
  },
});
