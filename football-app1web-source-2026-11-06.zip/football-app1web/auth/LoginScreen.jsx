import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Image,
  ActivityIndicator,
  Alert,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as Animatable from "react-native-animatable";
import { signInWithEmailAndPassword, sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../firebase";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    setError("");
    if (!email || !password) {
      setError("กรุณากรอกอีเมลและรหัสผ่านให้ครบ");
      return;
    }

    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email.trim(), password);
      // ✅ ถ้า App.js ใช้ onAuthStateChanged/conditional rendering อยู่ ไม่ต้อง navigate เอง
    } catch (err) {
      const code = err?.code || "";
      if (code === "auth/invalid-credential" || code === "auth/wrong-password") {
        setError("อีเมลหรือรหัสผ่านไม่ถูกต้อง");
      } else if (code === "auth/user-not-found") {
        setError("ไม่พบบัญชีผู้ใช้นี้");
      } else if (code === "auth/invalid-email") {
        setError("รูปแบบอีเมลไม่ถูกต้อง");
      } else if (code === "auth/too-many-requests") {
        setError("ลองใหม่อีกครั้งภายหลัง (ลองผิดหลายครั้ง)");
      } else if (code === "auth/operation-not-allowed") {
        setError("Email/Password sign-in is not enabled in Firebase.");
      } else if (code === "auth/unauthorized-domain") {
        setError("This website domain is not authorized in Firebase.");
      } else if (code === "auth/network-request-failed") {
        setError("Cannot connect to Firebase. Check your internet connection.");
      } else if (code === "auth/api-key-not-valid") {
        setError("Firebase API key is invalid. Check firebase.js.");
      } else {
        setError("เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่");
      }
      console.log("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    setError("");
    const mail = email.trim();

    if (!mail) {
      Alert.alert("ลืมรหัสผ่าน", "กรุณากรอกอีเมลก่อน แล้วกด “ลืมรหัสผ่าน” อีกครั้ง");
      return;
    }

    try {
      setLoading(true);
      await sendPasswordResetEmail(auth, mail);
      Alert.alert(
        "ส่งลิงก์รีเซ็ตรหัสผ่านแล้ว ✅",
        "กรุณาเช็กอีเมล (รวมถึงสแปม) แล้วทำตามขั้นตอนในอีเมล"
      );
    } catch (err) {
      const code = err?.code || "";
      if (code === "auth/invalid-email") {
        Alert.alert("ลืมรหัสผ่าน", "รูปแบบอีเมลไม่ถูกต้อง");
      } else if (code === "auth/user-not-found") {
        Alert.alert("ลืมรหัสผ่าน", "ไม่พบบัญชีที่ใช้อีเมลนี้");
      } else if (code === "auth/too-many-requests") {
        Alert.alert("ลืมรหัสผ่าน", "ถูกจำกัดการทำรายการ ลองใหม่ภายหลัง");
      } else {
        Alert.alert("ลืมรหัสผ่าน", "ส่งอีเมลไม่สำเร็จ กรุณาลองใหม่");
      }
      console.log("Reset password error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <StatusBar barStyle="light-content" />
      <LinearGradient colors={["#0b1224", "#1e3a8a", "#1d4ed8"]} style={styles.bg}>
        <SafeAreaView style={styles.safe}>
          <View style={styles.container}>
            <Animatable.View animation="fadeInDown" duration={700} style={styles.header}>
              <View style={styles.logoCircle}>
                <Image
                  source={require("../assets/i.png")}
                  style={styles.logo}
                  resizeMode="contain"
                />
              </View>

              <Text style={styles.title}>
                เข้าสู่ระบบ <Text style={styles.titleAccent}>Premier League Vision AI</Text>
              </Text>
            </Animatable.View>

            <Animatable.View animation="fadeInUp" duration={700} delay={150} style={styles.card}>
              <TextInput
                style={styles.input}
                placeholder="อีเมล"
                placeholderTextColor="#94a3b8"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
              <TextInput
                style={styles.input}
                placeholder="รหัสผ่าน"
                placeholderTextColor="#94a3b8"
                secureTextEntry
                value={password}
                onChangeText={setPassword}
              />

              {error ? <Text style={styles.error}>{error}</Text> : null}

              <TouchableOpacity
                style={[styles.button, loading && { opacity: 0.75 }]}
                onPress={handleLogin}
                disabled={loading}
                activeOpacity={0.85}
              >
                {loading ? <ActivityIndicator /> : <Text style={styles.buttonText}>เข้าสู่ระบบ</Text>}
              </TouchableOpacity>

              {/* ✅ โซนลิงก์ด้านล่าง (จัดกึ่งกลางแน่นอน) */}
              <View style={styles.linksWrap}>
                <TouchableOpacity
                  onPress={() => navigation.navigate("Register")}
                  activeOpacity={0.8}
                >
                  <Text style={styles.linkText}>ยังไม่มีบัญชี? สมัครสมาชิก</Text>
                </TouchableOpacity>

                {/* ✅ อยู่ “ใต้สมัครสมาชิก” ตามที่ขอ */}
                <TouchableOpacity onPress={handleForgotPassword} activeOpacity={0.8}>
                  <Text style={styles.linkTextSecondary}>ลืมรหัสผ่าน?</Text>
                </TouchableOpacity>
              </View>
            </Animatable.View>
          </View>
        </SafeAreaView>
      </LinearGradient>
    </>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  safe: { flex: 1 },
  container: {
    flex: 1,
    paddingHorizontal: 18,
    justifyContent: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: 18,
  },
  logoCircle: {
    width: 300,
    height: 300,
    borderRadius: 999,
    backgroundColor: "rgba(255,255,255,0.10)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 50,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.18)",
  },
  logo: {
    width: 250,
    height: 500,
    opacity: 0.95,
  },
  title: {
    color: "#e2e8f0",
    fontSize: 20,
    fontWeight: "700",
  },
  titleAccent: {
    color: "#facc15",
    fontWeight: "800",
  },
  card: {
    backgroundColor: "rgba(2,6,23,0.35)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    borderRadius: 16,
    padding: 16,
  },
  input: {
    height: 52,
    borderRadius: 12,
    backgroundColor: "rgba(15,23,42,0.65)",
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.20)",
    paddingHorizontal: 14,
    color: "#e2e8f0",
    marginBottom: 12,
    fontSize: 16,
  },
  error: {
    color: "#fb7185",
    marginBottom: 10,
    fontWeight: "600",
  },
  button: {
    height: 54,
    borderRadius: 14,
    backgroundColor: "#facc15",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 6,
  },
  buttonText: {
    color: "#0b1224",
    fontSize: 16,
    fontWeight: "800",
  },

  // ✅ สำคัญ: ทำให้ลิงก์อยู่กลาง และไม่ชิดขวา
  linksWrap: {
    marginTop: 20,
    alignItems: "center",
  },
  linkText: {
    textAlign: "center",
    color: "#e2e8f0",
    marginTop: 20,
    fontWeight: "600",
    fontSize: 16,
  },
  linkTextSecondary: {
    textAlign: "center",
    color: "#93c5fd",
    marginTop: 30,
    fontWeight: "800",
    fontSize: 16,
  },
});



