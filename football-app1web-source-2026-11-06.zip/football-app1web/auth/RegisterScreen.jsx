import React, { useState } from "react";
import {View,Text,TextInput,TouchableOpacity,StyleSheet,Image,} from "react-native";
import * as Animatable from "react-native-animatable"; //ใช้ทำ animation (fadeIn, zoomIn, pulse ฯลฯ)
import { LinearGradient } from "expo-linear-gradient"; //ทำพื้นหลัง gradient ไล่สี
import { StatusBar } from "expo-status-bar"; //จัดการแถบสถานะด้านบนของมือถือ
import { createUserWithEmailAndPassword } from "firebase/auth"; //ฟังก์ชันสมัครสมาชิก Firebase
import { auth } from "../firebase";

export default function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState(""); //เก็บอีเมลที่ผู้ใช้กรอก
  const [password, setPassword] = useState(""); //เก็บรหัสผ่าน
  const [confirm, setConfirm] = useState(""); //เก็บค่ารหัสผ่านที่พิมพ์ซ้ำ (ยืนยัน)
  const [error, setError] = useState(""); //เก็บข้อความ error เช่น รหัสไม่ตรงกัน
  
  //ฟังก์ชันสมัครสมาชิก
  const handleRegister = async () => {
    if (password !== confirm) {
      setError("⚠️ รหัสผ่านไม่ตรงกัน");
      return;
    }
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setError("❌ สมัครไม่สำเร็จ โปรดลองอีกครั้ง");
    }
  };

  return (
    <>
      {/*Status Bar โปร่งใส */}
      <StatusBar style="light" translucent backgroundColor="transparent" />

      <LinearGradient
        colors={["#0f172a", "#1e3a8a", "#312e81"]}
        style={styles.gradient}
      >
        <View style={styles.container}>
          {/* โลโก้พรีเมียร์ลีก + แสงเรือง */}
          <Animatable.View animation="fadeInDown" duration={1500}>
            <View style={styles.logoGlow}>
              <Animatable.Image
                animation="zoomIn"
                duration={2000}
                easing="ease-out"
                source={require("../assets/i.png")} 
                style={styles.appLogo}
                resizeMode="contain"
              />
            </View>
          </Animatable.View>

          <Animatable.Text
            animation="fadeInUp"
            duration={1000}
            style={styles.title}
          >
            สมัครสมาชิก Premier League Vision AI
          </Animatable.Text>

          <Animatable.View animation="fadeInUp" delay={400} style={styles.form}>
            <TextInput
              style={styles.input}
              placeholder="อีเมล"
              placeholderTextColor="#94a3b8"
              value={email}
              onChangeText={setEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="รหัสผ่าน"
              placeholderTextColor="#94a3b8"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
            <TextInput
              style={styles.input}
              placeholder="ยืนยันรหัสผ่าน"
              placeholderTextColor="#94a3b8"
              secureTextEntry
              value={confirm}
              onChangeText={setConfirm}
            />

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <Animatable.View
              animation="pulse"
              iterationCount="infinite"
              duration={2500}
            >
              <TouchableOpacity style={styles.button} onPress={handleRegister}>
                <Text style={styles.buttonText}>สร้างบัญชี</Text>
              </TouchableOpacity>
            </Animatable.View>

            <TouchableOpacity onPress={() => navigation.navigate("Login")}>
              <Text style={styles.linkText}>กลับไปหน้าเข้าสู่ระบบ</Text>
            </TouchableOpacity>
          </Animatable.View>
        </View>
      </LinearGradient>
    </>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },

  //กล่องแสงรอบโลโก้
  logoGlow: {
    backgroundColor: "rgba(250, 204, 21, 0.08)", 
    padding: 20,
    borderRadius: 120,
    shadowColor: "#facc15",
    shadowOpacity: 0.4, 
    shadowRadius: 12,
    elevation: 6,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 15,
  },

  //โลโก้แอป
  appLogo: {
    width: 160, 
    height: 160,
    opacity: 0.85, 
  },

  //ชื่อแอป
  title: {
    color: "#facc15",
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 25,
    textAlign: "center",
  },

  //ฟอร์ม input
  form: {
    width: "100%",
  },
  input: {
    backgroundColor: "rgba(30, 41, 59, 0.9)",
    color: "#fff",
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
    fontSize: 16,
  },

  //ปุ่มสมัครสมาชิก
  button: {
    backgroundColor: "#facc15",
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
    marginVertical: 10,
  },
  buttonText: {
    color: "#0f172a",
    fontWeight: "bold",
    fontSize: 16,
  },

  //ลิงก์กลับไปหน้า Login
  linkText: {
    color: "#facc15",
    marginTop: 8,
    textAlign: "center",
  },

  //แสดง error
  error: {
    color: "#ef4444",
    marginBottom: 8,
  },
});


