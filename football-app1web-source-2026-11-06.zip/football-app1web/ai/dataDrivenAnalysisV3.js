// อ่านข้อมูลฟุตบอลในแอป แล้วให้ Gemini คาดผลและเขียนบทวิเคราะห์
import {
  getPremierLeagueHistoricalMatches,
  getPremierLeagueMatches,
  getPremierLeagueStandings,
  getPremierLeagueTeamSquad,
  PREMIER_LEAGUE_SEASON,
} from "../data/premierLeagueData";

// อ่านคีย์สำหรับเชื่อมต่อ Gemini
const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY;
// ใช้รุ่นที่ทดสอบกับคีย์เว็บแล้ว แทน 2.5 Flash ที่บัญชีใหม่เรียกไม่ได้
const GEMINI_MODEL = "gemini-3.5-flash-lite";
const GEMINI_INTERACTIONS_URL = "https://generativelanguage.googleapis.com/v1beta/interactions";

// ลองใหม่เฉพาะปัญหาชั่วคราว เช่น โควตาต่อนาทีเต็มหรือบริการไม่พร้อม
const isTransientGeminiError = (error) =>
  [408, 429, 500, 502, 503, 504].includes(error?.status);

// อ่านเฉพาะข้อความคำตอบสุดท้ายจาก Interactions API
const getInteractionText = (payload) => {
  if (typeof payload.output_text === "string" && payload.output_text.trim()) {
    return payload.output_text.trim();
  }
  const step = [...(payload.steps || [])].reverse().find((item) => item?.type === "model_output");
  return (step?.content || [])
    .filter((item) => item?.type === "text")
    .map((item) => item.text || "")
    .join("\n")
    .trim();
};

const generateAnalysis = async (prompt) => {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const response = await fetch(GEMINI_INTERACTIONS_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": GEMINI_API_KEY },
        body: JSON.stringify({
          model: GEMINI_MODEL,
          input: prompt,
          store: false,
          generation_config: { max_output_tokens: 8192 },
        }),
      });
      const payload = await response.json();
      if (!response.ok) {
        const error = new Error(payload?.error?.message || "Gemini request failed");
        error.status = response.status;
        throw error;
      }
      const text = getInteractionText(payload);
      if (!text) throw new Error("Gemini returned no analysis");
      return text;
    } catch (error) {
      if (!isTransientGeminiError(error) || attempt === 2) throw error;
      await new Promise((resolve) => setTimeout(resolve, 1000 * 2 ** attempt));
    }
  }
};

// แสดงปัญหาการเชื่อมต่อเป็นภาษาไทย แทนข้อความ API ยาว ๆ บนหน้าจอ
const describeAnalysisError = (error) => {
  if (error?.status === 404) return "โมเดล AI ที่ตั้งค่าไว้ยังใช้งานไม่ได้ กรุณาติดต่อผู้ดูแล";
  if ([400, 403].includes(error?.status)) return "เชื่อมต่อ AI ไม่สำเร็จ กรุณาตรวจสอบคีย์ API และสิทธิ์การใช้งาน";
  if (error?.status === 429) return "โควตา AI เต็ม กรุณาลองใหม่ภายหลัง";
  if (isTransientGeminiError(error)) return "บริการ AI ไม่พร้อมชั่วคราว กรุณาลองวิเคราะห์ใหม่ภายหลัง";
  return "วิเคราะห์ไม่สำเร็จ กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ตหรือลองใหม่อีกครั้ง";
};

// รวมชื่อเรียกอื่นของทีมให้ตรงกับชื่อมาตรฐาน
const TEAM_ALIASES = {
  "man city": "manchester city",
  "manchester city fc": "manchester city",
  "man united": "manchester united",
  "manchester united fc": "manchester united",
  wolves: "wolverhampton wanderers",
  "wolverhampton wanderers fc": "wolverhampton wanderers",
  tottenham: "tottenham hotspur",
  spurs: "tottenham hotspur",
  "tottenham hotspur fc": "tottenham hotspur",
  brighton: "brighton & hove albion",
  "brighton & hove albion fc": "brighton & hove albion",
  "west ham": "west ham united",
  "west ham united fc": "west ham united",
  newcastle: "newcastle united",
  "newcastle united fc": "newcastle united",
  "nott'm forest": "nottingham forest",
  "nottm forest": "nottingham forest",
};

// ปรับชื่อทีมก่อนค้นหาหรือเปรียบเทียบ
const normalizeTeamName = (value = "") => {
  const normalized = value.trim().toLowerCase();
  return TEAM_ALIASES[normalized] || normalized;
};

// อ่านฤดูกาลและตารางคะแนนจากข้อมูลของแอป
const getStandings = async () => {
  return {
    season: PREMIER_LEAGUE_SEASON,
    standings: getPremierLeagueStandings(),
  };
};

// อ่านแมตช์ตามปีเริ่มฤดูกาล ทั้งฤดูกาลปัจจุบันและข้อมูลย้อนหลัง
const getMatches = async (season) => {
  return Number(season) === Number(PREMIER_LEAGUE_SEASON.startYear)
    ? getPremierLeagueMatches()
    : getPremierLeagueHistoricalMatches().filter(
        (match) => Number(match.season?.startYear) === Number(season)
      );
};

// อ่านรายชื่อนักเตะตามรหัสทีม
const getTeamSquad = async (teamId) => getPremierLeagueTeamSquad(teamId);

// รวบรวมชื่อเต็ม ชื่อสั้น และตัวย่อไว้ใช้ค้นหาทีม
const getTeamNames = (standing) =>
  [
    standing?.team?.name,
    standing?.team?.shortName,
    standing?.team?.tla,
  ]
    .filter(Boolean)
    .map((name) => normalizeTeamName(name));

// ค้นหาสถิติในตารางคะแนนของทีมที่เลือก
const findStanding = (standings, teamName) => {
  const target = normalizeTeamName(teamName);
  return standings.find((standing) => getTeamNames(standing).includes(target)) || null;
};

// หาผลของทีมในแมตช์: W ชนะ, D เสมอ, L แพ้
const getTeamOutcome = (match, teamId) => {
  const homeScore = match.score?.fullTime?.home;
  const awayScore = match.score?.fullTime?.away;

  if (homeScore === awayScore) {
    return "D";
  }

  const isHome = match.homeTeam?.id === teamId;
  return isHome
    ? homeScore > awayScore
      ? "W"
      : "L"
    : awayScore > homeScore
      ? "W"
      : "L";
};

// จัดวันที่ ชื่อทีม และสกอร์เป็นข้อความหนึ่งบรรทัด
const formatMatchLine = (match, teamId = null) => {
  const dateText = match.utcDate
    ? new Date(match.utcDate).toLocaleDateString("th-TH", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : "-";
  const homeName = match.homeTeam?.shortName || match.homeTeam?.name || "-";
  const awayName = match.awayTeam?.shortName || match.awayTeam?.name || "-";
  const homeScore = match.score?.fullTime?.home ?? "-";
  const awayScore = match.score?.fullTime?.away ?? "-";
  const outcome = teamId ? ` (${getTeamOutcome(match, teamId)})` : "";

  return `${dateText}: ${homeName} ${homeScore}-${awayScore} ${awayName}${outcome}`;
};

// เลือกฟอร์ม 10 นัดล่าสุดที่จบแล้ว รวมทั้งเหย้าและเยือน
const getRecentMatches = (matches, teamId, limit = 10) =>
  matches
    .filter(
      (match) =>
        match.status === "FINISHED" &&
        (match.homeTeam?.id === teamId || match.awayTeam?.id === teamId)
    )
    .sort((a, b) => Date.parse(b.utcDate || 0) - Date.parse(a.utcDate || 0))
    .slice(0, limit)
    .map((match) => formatMatchLine(match, teamId));

// เลือกทุกนัดที่สองทีมพบกันจากช่วงฤดูกาลที่โหลด พร้อมระบุฤดูกาลของแต่ละนัด
const getHeadToHeadMatches = (matches, homeTeamId, awayTeamId) =>
  matches
    .filter((match) => {
      if (match.status !== "FINISHED") {
        return false;
      }

      const matchHomeId = match.homeTeam?.id;
      const matchAwayId = match.awayTeam?.id;

      return (
        (matchHomeId === homeTeamId && matchAwayId === awayTeamId) ||
        (matchHomeId === awayTeamId && matchAwayId === homeTeamId)
      );
    })
    .sort((a, b) => Date.parse(b.utcDate || 0) - Date.parse(a.utcDate || 0))
    .map((match) => {
      const year = Number(match.season?.startYear);
      const seasonLabel = `${year}/${String(year + 1).slice(-2)}`;
      return `${formatMatchLine(match)} (ฤดูกาล ${seasonLabel})`;
    });

// หาปีเริ่มฤดูกาลจากข้อมูล หรืออิงวันที่ปัจจุบันถ้าข้อมูลไม่พร้อม
const getSeasonStartYear = (season) => {
  const startYear = Number(season?.startDate?.slice(0, 4));

  if (Number.isInteger(startYear)) {
    return startYear;
  }

  const currentDate = new Date();
  return currentDate.getMonth() >= 6
    ? currentDate.getFullYear()
    : currentDate.getFullYear() - 1;
};

// รวมตารางคะแนน ฟอร์ม ผลพบกัน และนักเตะ เพื่อเตรียมส่งให้ Gemini
const buildFootballContext = async (home, away) => {
  const { season, standings } = await getStandings();
  const homeStanding = findStanding(standings, home);
  const awayStanding = findStanding(standings, away);

  if (!homeStanding || !awayStanding) {
    throw new Error("ไม่พบทีมในตาราง Premier League จาก football-data.org");
  }

  const currentSeason = getSeasonStartYear(season);
  // รวมฤดูกาลปัจจุบันกับ 4 ฤดูกาลก่อนหน้า เช่น 2026/27 และ 2022/23–2025/26
  const seasonYears = Array.from({ length: 5 }, (_, index) => currentSeason - index);
  const [seasonMatches, homeSquad, awaySquad] =
    await Promise.all([
      Promise.all(seasonYears.map((year) => getMatches(year))),
      getTeamSquad(homeStanding.team?.id).catch(() => []),
      getTeamSquad(awayStanding.team?.id).catch(() => []),
    ]);
  const allMatches = seasonMatches.flat();

  return {
    homeTeam: {
      name: homeStanding.team?.name,
      shortName: homeStanding.team?.shortName,
      position: homeStanding.position,
      points: homeStanding.points,
      playedGames: homeStanding.playedGames,
      won: homeStanding.won,
      draw: homeStanding.draw,
      lost: homeStanding.lost,
      goalsFor: homeStanding.goalsFor,
      goalsAgainst: homeStanding.goalsAgainst,
      goalDifference: homeStanding.goalDifference,
      recentMatches: getRecentMatches(allMatches, homeStanding.team?.id),
      squad: homeSquad,
    },
    awayTeam: {
      name: awayStanding.team?.name,
      shortName: awayStanding.team?.shortName,
      position: awayStanding.position,
      points: awayStanding.points,
      playedGames: awayStanding.playedGames,
      won: awayStanding.won,
      draw: awayStanding.draw,
      lost: awayStanding.lost,
      goalsFor: awayStanding.goalsFor,
      goalsAgainst: awayStanding.goalsAgainst,
      goalDifference: awayStanding.goalDifference,
      recentMatches: getRecentMatches(allMatches, awayStanding.team?.id),
      squad: awaySquad,
    },
    headToHead: getHeadToHeadMatches(
      allMatches,
      homeStanding.team?.id,
      awayStanding.team?.id
    ),
  };
};

// จัดสถิติตารางคะแนนของทีมเป็นข้อความ
const formatTeamStats = (label, team) => [
  `${label}: ${team.name || team.shortName || "-"}`,
  `อันดับ: ${team.position ?? "-"}`,
  `คะแนน: ${team.points ?? "-"}`,
  `แข่ง: ${team.playedGames ?? "-"}`,
  `ชนะ-เสมอ-แพ้: ${team.won ?? "-"}-${team.draw ?? "-"}-${team.lost ?? "-"}`,
  `ประตูได้-เสีย: ${team.goalsFor ?? "-"}-${team.goalsAgainst ?? "-"}`,
  `ผลต่างประตู: ${team.goalDifference ?? "-"}`,
].join("\n");

// จัดรายการเป็นข้อความ หรือแจ้งว่าไม่มีข้อมูล
const formatList = (items = [], emptyText) =>
  items.length ? items.map((item) => `- ${item}`).join("\n") : `- ${emptyText}`;

// จัดรายชื่อนักเตะพร้อมตำแหน่งและหมายเลขเสื้อ
const formatSquad = (players = []) =>
  players.length
    ? players
        .map((player) => {
          const shirt = player.shirtNumber ? ` เบอร์ ${player.shirtNumber}` : "";
          return `- ${player.name} ตำแหน่ง ${player.position || "-"}${shirt}`;
        })
        .join("\n")
    : "- ไม่มีรายชื่อนักเตะ";

// สร้างคำสั่งให้ Gemini วิเคราะห์ภาษาไทย 7 หัวข้อ โดยใช้ข้อมูลที่เตรียมไว้
const buildThaiAnalysisPrompt = (home, away, footballContext) => `
คุณคือ AI วิเคราะห์บอล
ตอบเป็นภาษาไทยทั้งหมด
ใช้เฉพาะข้อมูลจริงที่ให้ไว้ด้านล่างสำหรับหัวข้อ 2, 3 และ 4
หัวข้อ 1, 5, 6 และ 7 ให้ประเมินต่อจากข้อมูลที่มี
ไม่ต้องใช้ตาราง
เขียนให้อ่านง่ายบนมือถือ

ทีมเหย้า: ${home}
ทีมเยือน: ${away}

ข้อมูลตารางคะแนน
${formatTeamStats("ทีมเหย้า", footballContext.homeTeam)}

${formatTeamStats("ทีมเยือน", footballContext.awayTeam)}

ฟอร์ม 10 นัดหลังสุดของทีมเหย้า
${formatList(footballContext.homeTeam.recentMatches, "ไม่มีข้อมูลจากแหล่งข้อมูลฟุตบอล")}

ฟอร์ม 10 นัดหลังสุดของทีมเยือน
${formatList(footballContext.awayTeam.recentMatches, "ไม่มีข้อมูลจากแหล่งข้อมูลฟุตบอล")}

ผลการพบกันทุกนัด (ฤดูกาลปัจจุบันและ 4 ฤดูกาลย้อนหลัง)
${formatList(footballContext.headToHead, "ไม่มีข้อมูลการพบกันล่าสุดจากแหล่งข้อมูลฟุตบอล")}

รายชื่อนักเตะทีมเหย้า
${formatSquad(footballContext.homeTeam.squad)}

รายชื่อนักเตะทีมเยือน
${formatSquad(footballContext.awayTeam.squad)}

ให้ตอบตามหัวข้อนี้และห้ามสลับลำดับ:
1. ภาพรวมเกม
2. ตารางคะแนนและสถิติหลัก
3. ฟอร์ม 10 นัดหลังสุด
4. ผลการพบกัน (ฤดูกาลปัจจุบันและ 4 ฤดูกาลย้อนหลัง)
5. ตัวจริงและตัวสำรองที่คาดว่าจะลงสนาม
6. เปอร์เซ็นต์โอกาสชนะรวม 100
7. สกอร์ที่คาด

ข้อกำหนด:
- หัวข้อ 2 ต้องบอกอันดับในตาราง คะแนน แข่ง ชนะ เสมอ แพ้ ประตูได้ ประตูเสีย และผลต่างประตูของทั้งสองทีม
- หัวข้อ 3 ต้องใช้ฟอร์ม 10 นัดหลังสุดที่ให้ไว้เท่านั้น
- หัวข้อ 4 ต้องแสดงทุกนัดที่ให้ไว้ พร้อมฤดูกาล เรียงจากใหม่ไปเก่า ห้ามย่อเหลือเฉพาะนัดล่าสุดหรือ 5 นัด และห้ามแต่งผลแข่งเพิ่ม
- หัวข้อ 5 ต้องขึ้นต้นด้วย "คาดการณ์โดย AI"
- หัวข้อ 5 ต้องบอกชื่อนักเตะตัวจริง 11 คนและตัวสำรองของทั้งสองทีม
- หัวข้อ 5 ต้องใช้เฉพาะชื่อจากรายชื่อนักเตะที่ให้ไว้เท่านั้น ห้ามแต่งชื่อผู้เล่นเอง
- ถ้าทีมใดไม่มีรายชื่อนักเตะ ให้บอกว่าไม่มีรายชื่อนักเตะสำหรับทีมนั้น
- หัวข้อ 6 ต้องขึ้นต้นด้วย "คาดการณ์โดย AI" และเปอร์เซ็นต์ทั้งสามทางต้องรวมกันให้ได้ 100%
- หัวข้อ 7 ต้องขึ้นต้นด้วย "คาดการณ์โดย AI"
- คำตอบต้องเป็นบทวิเคราะห์ ไม่ใช่คำแนะนำการพนัน
`;

// ใช้ข้อมูลจริงแสดงหัวข้อ 4 โดยตรง เพื่อให้ครบทุกนัดแม้ AI จะย่อบทวิเคราะห์
const includeHeadToHeadSection = (analysis, context) => {
  const heading = "4. ผลการพบกัน (ฤดูกาลปัจจุบันและ 4 ฤดูกาลย้อนหลัง)";
  const list = context.headToHead.length
    ? context.headToHead.map((match) => `• ${match}`).join("\n")
    : "ไม่มีข้อมูลการพบกันในช่วงฤดูกาลนี้";
  const section = `${heading}\n${list}\n\n`;
  const fourthHeading = /^[ \t]*(?:#{1,6}[ \t]*)?(?:\*\*|__)?4[.)][ \t]+[^\n]*/m;
  const followingHeading = /^[ \t]*(?:#{1,6}[ \t]*)?(?:\*\*|__)?[5-7][.)][ \t]+[^\n]*/m;
  const start = analysis.search(fourthHeading);
  if (start >= 0) {
    const remaining = analysis.slice(start);
    const end = remaining.search(followingHeading);
    return analysis.slice(0, start) + section + (end >= 0 ? remaining.slice(end) : "");
  }
  const end = analysis.search(followingHeading);
  if (end >= 0) return analysis.slice(0, end) + section + analysis.slice(end);
  return analysis + `\n\n${section}`;
};

// ตรวจชื่อทีมและคีย์ เรียก Gemini แล้วคืนบทวิเคราะห์หรือข้อความผิดพลาด
export async function predictMatchFromFootballData(home, away) {
  if (normalizeTeamName(home) === normalizeTeamName(away)) {
    return "กรุณาเลือกคนละทีมสำหรับทีมเหย้าและทีมเยือน";
  }

  if (!GEMINI_API_KEY) {
    return "ยังวิเคราะห์ไม่ได้ เพราะยังไม่ได้ตั้งค่า EXPO_PUBLIC_GEMINI_API_KEY";
  }

  try {
    const footballContext = await buildFootballContext(home, away);
    const analysis = await generateAnalysis(
      buildThaiAnalysisPrompt(home, away, footballContext)
    );
    return includeHeadToHeadSection(analysis, footballContext);
  } catch (error) {
    console.log("AI football-data analysis error:", error);
    return describeAnalysisError(error);
  }
}
