import { useState } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { predictMatchFromFootballData } from "../ai/dataDrivenAnalysisV3";
import { getPremierLeagueTeamNames } from "../data/premierLeagueData";

const PREMIER_LEAGUE_TEAMS = getPremierLeagueTeamNames();

const cleanMarkdownLine = (line) => {
  let text = line
    .replace(/^#{1,6}\s*/g, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/__(.*?)__/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .trim();

  if (text.startsWith("|") && text.includes("|")) {
    const cells = text
      .split("|")
      .map((cell) => cell.trim())
      .filter(Boolean);

    if (cells.length && cells.every((cell) => /^:?-+:?$/.test(cell))) {
      return "";
    }

    return cells.join(" | ");
  }

  if (/^[-*]\s/.test(text)) {
    return `• ${text.slice(2).trim()}`;
  }

  return text;
};

const getLineStyle = (line) => {
  // ใช้สีทองเฉพาะหัวข้อหลัก ไม่รวมลำดับเลขหน้ารายชื่อนักเตะ
  if (/^[1-7][.)]\s*(?:ภาพรวม|ตารางคะแนน|ฟอร์ม|ผลการพบกัน|ตัวจริง|เปอร์เซ็นต์|โอกาสชนะ|สกอร์)/.test(line)) {
    return "heading";
  }

  if (
    line.startsWith("ทีมเหย้า:") ||
    line.startsWith("ทีมเยือน:") ||
    line.startsWith("คาดการณ์โดย AI:") ||
    line.startsWith("สกอร์ที่คาด:")
  ) {
    return "subheading";
  }

  if (line.startsWith("•")) {
    return "bullet";
  }

  return "body";
};

export default function AIScreenData() {
  const [home, setHome] = useState("");
  const [away, setAway] = useState("");
  const [result, setResult] = useState("");
  const [selectTarget, setSelectTarget] = useState("home");
  const [predicting, setPredicting] = useState(false);

  const handlePredict = async () => {
    if (!home.trim() || !away.trim()) {
      setResult("กรุณากรอกทีมเหย้าและทีมเยือน");
      return;
    }

    setPredicting(true);
    setResult("กำลังให้ AI วิเคราะห์...");

    try {
      setResult(await predictMatchFromFootballData(home, away));
    } catch (error) {
      console.log("Predict error:", error);
      setResult("วิเคราะห์ไม่สำเร็จ");
    } finally {
      setPredicting(false);
    }
  };

  const swapTeams = () => {
    setHome(away);
    setAway(home);
  };

  const selectTeam = (team) => {
    if (selectTarget === "home") {
      setHome(team);
      return;
    }

    setAway(team);
  };

  const renderResult = () => {
    const lines = result.split(/\r?\n/);

    return lines.map((rawLine, index) => {
      const line = cleanMarkdownLine(rawLine);

      if (!line) {
        return <View key={`space-${index}`} style={styles.resultSpacer} />;
      }

      const variant = getLineStyle(line);
      const lineStyles = [styles.resultLine];

      if (variant === "heading") {
        lineStyles.push(styles.resultHeading);
      } else if (variant === "subheading") {
        lineStyles.push(styles.resultSubheading);
      } else if (variant === "bullet") {
        lineStyles.push(styles.resultBullet);
      }

      return (
        <Text key={`line-${index}`} style={lineStyles}>
          {line}
        </Text>
      );
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>AI วิเคราะห์ฟุตบอล</Text>
      <Text style={styles.sourceNote}>วิเคราะห์จาก AI โดยตรง</Text>

      <TextInput
        style={[styles.input, selectTarget === "home" && styles.inputActive]}
        value={home}
        placeholder="ทีมเหย้า"
        placeholderTextColor="#94a3b8"
        onChangeText={setHome}
        onFocus={() => setSelectTarget("home")}
      />
      <TextInput
        style={[styles.input, selectTarget === "away" && styles.inputActive]}
        value={away}
        placeholder="ทีมเยือน"
        placeholderTextColor="#94a3b8"
        onChangeText={setAway}
        onFocus={() => setSelectTarget("away")}
      />

      <TouchableOpacity style={styles.swapBtn} onPress={swapTeams}>
        <Text style={styles.swapText}>สลับทีมเหย้า / เยือน</Text>
      </TouchableOpacity>

      <Text style={styles.subTitle}>
        เลือกทีม ({selectTarget === "home" ? "ทีมเหย้า" : "ทีมเยือน"})
      </Text>

      <View style={styles.teamWrap}>
        {PREMIER_LEAGUE_TEAMS.map((team) => (
          <TouchableOpacity
            key={team}
            style={[
              styles.teamBtn,
              (home === team || away === team) && styles.teamBtnSelected,
            ]}
            onPress={() => selectTeam(team)}
          >
            <Text style={styles.teamText}>{team}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={[styles.button, predicting && styles.buttonDisabled]}
        onPress={handlePredict}
        disabled={predicting}
      >
        <Text style={styles.buttonText}>
          {predicting ? "กำลังวิเคราะห์..." : "วิเคราะห์"}
        </Text>
      </TouchableOpacity>

      {result ? <View style={styles.resultBox}>{renderResult()}</View> : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0f172a", padding: 20 },
  title: {
    color: "#38bdf8",
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 8,
  },
  sourceNote: {
    color: "#cbd5e1",
    textAlign: "center",
    marginBottom: 16,
    fontSize: 13,
  },
  input: {
    backgroundColor: "#1e293b",
    borderColor: "#1e293b",
    borderWidth: 1,
    color: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  inputActive: {
    borderColor: "#facc15",
  },
  swapBtn: {
    backgroundColor: "#334155",
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 14,
  },
  swapText: { color: "#facc15", fontWeight: "bold" },
  subTitle: { color: "#facc15", marginBottom: 8 },
  teamWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 20,
    justifyContent: "center",
  },
  teamBtn: {
    backgroundColor: "#1e40af",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    margin: 4,
  },
  teamBtnSelected: {
    backgroundColor: "#0369a1",
  },
  teamText: { color: "#fff", fontSize: 13 },
  button: {
    backgroundColor: "#facc15",
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: { color: "#0f172a", fontWeight: "bold", fontSize: 16 },
  resultBox: {
    backgroundColor: "#1e293b",
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
  },
  resultLine: {
    color: "#f8fafc",
    lineHeight: 24,
    fontSize: 15,
  },
  resultHeading: {
    color: "#facc15",
    fontSize: 17,
    fontWeight: "bold",
    marginTop: 4,
  },
  resultSubheading: {
    color: "#93c5fd",
    fontWeight: "bold",
    marginTop: 2,
  },
  resultBullet: {
    paddingLeft: 6,
  },
  resultSpacer: {
    height: 8,
  },
});
