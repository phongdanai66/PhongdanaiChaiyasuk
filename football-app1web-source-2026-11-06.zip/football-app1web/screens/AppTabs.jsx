import React from "react";  //ใช้สร้างคอมโพเนนต์
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";  //สร้าง bottom tab navigation (เมนูแท็บด้านล่าง)
import { Ionicons } from "@expo/vector-icons"; //ชุดไอคอนจาก Expo
import { View, Text, Alert, Platform } from "react-native"; //คอมโพเนนต์พื้นฐานของ React Native
import { signOut } from "firebase/auth";  //ฟังก์ชันสำหรับออกจากระบบจาก Firebase Authentication
import { auth } from "../firebase";

//import ไฟล์หน้าจออื่นมาใช้
import MatchesScreen from "./MatchesScreenFixed";
import AIScreen from "./AIScreenData";
import StandingsScreen from "./StandingsScreenSync";

const Tab = createBottomTabNavigator();

export default function AppTabs() {
  const signOutUser = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.log("Logout error:", error);
    }
  };

  const handleLogout = () => { //ฟังก์ชัน handleLogout
    if (Platform.OS === "web") {
      if (window.confirm("คุณต้องการออกจากระบบหรือไม่?")) {
        signOutUser();
      }
      return;
    }

    Alert.alert("ออกจากระบบ", "คุณต้องการออกจากระบบหรือไม่?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ออกจากระบบ",
        style: "destructive",
        onPress: signOutUser,
      },
    ]);
  };

  //การตั้งค่า Tab.Navigator
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,  //ไม่แสดง header ด้านบน
        tabBarStyle: {  //กำหนดสีพื้นหลังแท็บ, เส้นขอบด้านบน, ความสูง
          backgroundColor: "#0f172a",
          borderTopColor: "#1e293b",
          height: 65,
        },
        tabBarActiveTintColor: "#facc15", //สีปุ่มเวลาถูกเลือก 
        tabBarInactiveTintColor: "#94a3b8", //สีปุ่มที่ไม่ได้เลือก 
        tabBarIcon: ({ color }) => {  //เลือกไอคอนต่างกันตามชื่อ route
          let iconName;
          if (route.name === "Matches") iconName = "football";
          else if (route.name === "AI") iconName = "sparkles";
          else if (route.name === "Standings") iconName = "stats-chart";
          else if (route.name === "Logout") iconName = "exit-outline";
          return <Ionicons name={iconName} size={22} color={color} />;
        },
        tabBarLabelStyle: { fontSize: 12, fontWeight: "bold" },  //กำหนดขนาด/น้ำหนักตัวอักษร label
      })}
    >
      <Tab.Screen name="Matches" component={MatchesScreen} />
      <Tab.Screen name="AI" component={AIScreen} />
      <Tab.Screen name="Standings" component={StandingsScreen} />
      
      <Tab.Screen
        name="Logout"
        component={EmptyScreen}
        listeners={{
          tabPress: (e) => {
            e.preventDefault(); 
            handleLogout();     
          },
        }}
        options={{
          tabBarLabel: "ออกจากระบบ",
          tabBarLabelStyle: { fontSize: 12, fontWeight: "bold", color: "#ef4444" },
          tabBarIcon: ({ focused }) => (
            <Ionicons
              name="exit-outline"
              size={22}
              color={focused ? "#ef4444" : "#ef4444"}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

//คือหน้าว่างสีพื้นหลังเข้ม
function EmptyScreen() {
  return <View style={{ flex: 1, backgroundColor: "#0f172a" }} />;
}
