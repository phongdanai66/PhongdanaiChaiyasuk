import { useEffect, useState } from "react";
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { ActivityIndicator, Card } from "react-native-paper";
import {
  getPremierLeagueMatches,
  PREMIER_LEAGUE_SEASON_LABEL,
} from "../data/premierLeagueData";

const getLastUpdatedLabel = (items) => {
  const timestamps = items
    .map((item) => item.lastSyncedAt)
    .filter(Boolean)
    .map((value) => Date.parse(value))
    .filter((value) => !Number.isNaN(value));

  if (timestamps.length === 0) {
    return "Last updated: -";
  }

  const latest = new Date(Math.max(...timestamps));
  return `Last updated: ${latest.toLocaleString("th-TH", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })}`;
};

export default function MatchesScreenFixed() {
  const [matches, setMatches] = useState([]);
  const [filteredMatches, setFilteredMatches] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const applyViewState = (allMatches, nextSearch) => {
    const keyword = nextSearch.trim().toLowerCase();
    let nextMatches = [...allMatches];

    if (keyword) {
      nextMatches = nextMatches.filter((match) => {
        const home = (match.homeTeam?.name || "").toLowerCase();
        const away = (match.awayTeam?.name || "").toLowerCase();
        return home.includes(keyword) || away.includes(keyword);
      });
    }

    setFilteredMatches(nextMatches);
  };

  const setMatchState = (nextMatches, nextSearch = search) => {
    setMatches(nextMatches);
    applyViewState(nextMatches, nextSearch);
  };

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      setErrorMessage("");

      try {
        setMatchState(getPremierLeagueMatches());
      } catch (error) {
        console.log("Matches load error:", error);
        setErrorMessage("โหลดข้อมูลแมตช์ไม่สำเร็จ");
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  const handleSearch = (text) => {
    setSearch(text);
    applyViewState(matches, text);
  };

  const lastUpdatedLabel = getLastUpdatedLabel(matches);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#7dd3fc" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={require("../assets/logo.jpg")} style={styles.logo} />
        <Text style={styles.title}>
          Premier League {PREMIER_LEAGUE_SEASON_LABEL}
        </Text>
      </View>

      <Text style={styles.lastUpdatedText}>{lastUpdatedLabel}</Text>

      {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}

      <TextInput
        style={styles.searchInput}
        placeholder="ค้นหาทีม"
        placeholderTextColor="#94a3b8"
        value={search}
        onChangeText={handleSearch}
      />

      {filteredMatches.length === 0 ? (
        <Text style={styles.noResult}>ไม่พบแมตช์</Text>
      ) : (
        filteredMatches.map((match) => {
          const home = match.homeTeam?.name || "-";
          const away = match.awayTeam?.name || "-";
          const homeCrest = match.homeTeam?.crest || "";
          const awayCrest = match.awayTeam?.crest || "";
          const matchDate = match.utcDate
            ? new Date(match.utcDate).toLocaleString("th-TH", {
                day: "2-digit",
                month: "short",
                hour: "2-digit",
                minute: "2-digit",
              })
            : "-";

          const scoreText =
            match.status === "FINISHED"
              ? `${match.score?.fullTime?.home ?? 0} : ${
                  match.score?.fullTime?.away ?? 0
                }`
              : match.status;

          return (
            <Card key={match.id} style={styles.card}>
              <Card.Content>
                <Text style={styles.dateText}>{matchDate}</Text>
                <View style={styles.matchRow}>
                  <View style={styles.teamBlock}>
                    {homeCrest ? (
                      <Image source={{ uri: homeCrest }} style={styles.teamLogo} />
                    ) : (
                      <View style={styles.teamLogoFallback} />
                    )}
                    <Text style={styles.teamRoleLabel}>HOME</Text>
                    <Text style={[styles.teamName, styles.homeTeamName]}>{home}</Text>
                  </View>
                  <Text style={styles.scoreText}>{scoreText}</Text>
                  <View style={styles.teamBlock}>
                    {awayCrest ? (
                      <Image source={{ uri: awayCrest }} style={styles.teamLogo} />
                    ) : (
                      <View style={styles.teamLogoFallback} />
                    )}
                    <Text style={styles.teamRoleLabel}>AWAY</Text>
                    <Text style={[styles.teamName, styles.awayTeamName]}>{away}</Text>
                  </View>
                </View>
              </Card.Content>
            </Card>
          );
        })
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0a122a", padding: 16 },

  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  header: { alignItems: "center", marginBottom: 12 },
  logo: { width: 80, height: 80 },
  title: { color: "#59a8f6", fontSize: 20, fontWeight: "bold" },

  lastUpdatedText: {
    color: "#cbd5e1",
    textAlign: "center",
    marginBottom: 10,
    fontSize: 12,
  },

  errorText: {
    color: "#fca5a5",
    textAlign: "center",
    marginBottom: 10,
  },

  searchInput: {
    backgroundColor: "#1e3a8a",
    padding: 10,
    borderRadius: 8,
    color: "#fff",
    marginBottom: 10,
  },

  card: {
    marginBottom: 10,
    backgroundColor: "#172554",
  },

  dateText: {
    color: "#cbd5e1",
    marginBottom: 8,
    textAlign: "center",
  },

  matchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  teamBlock: {
    flex: 1,
    alignItems: "center",
    gap: 8,
  },

  teamLogo: {
    width: 34,
    height: 34,
    resizeMode: "contain",
  },

  teamLogoFallback: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "#334155",
  },

  teamName: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 13,
  },

  teamRoleLabel: {
    color: "#94a3b8",
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.8,
  },

  homeTeamName: {
    textAlign: "left",
  },

  awayTeamName: {
    textAlign: "right",
  },

  scoreText: {
    color: "#7dd3fc",
    minWidth: 90,
    textAlign: "center",
    fontWeight: "700",
  },

  noResult: {
    color: "#aaa",
    textAlign: "center",
    marginTop: 20,
  },
});
