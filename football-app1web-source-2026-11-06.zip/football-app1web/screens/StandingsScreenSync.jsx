import { useEffect, useState } from "react";
import { Image, ScrollView, StyleSheet, View } from "react-native";
import { ActivityIndicator, Card, Text } from "react-native-paper";
import {
  getPremierLeagueStandings,
  PREMIER_LEAGUE_SEASON_LABEL,
} from "../data/premierLeagueData";

const getCrestUrl = (crest) => {
  if (!crest) {
    return "";
  }

  return crest.endsWith(".svg") ? crest.replace(".svg", ".png") : crest;
};

const getLastUpdatedLabel = (items) => {
  const timestamps = items
    .map((item) => item.lastSyncedAt)
    .filter(Boolean)
    .map((value) => Date.parse(value))
    .filter((value) => !Number.isNaN(value));

  if (timestamps.length === 0) {
    return "Last updated: -";
  }

  const latest = new Date(Math.max(...timestamps));
  return `Last updated: ${latest.toLocaleString("th-TH", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })}`;
};

export default function StandingsScreenSync() {
  const [standings, setStandings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const lastUpdatedLabel = getLastUpdatedLabel(standings);

  const setStandingsState = (nextStandings) => {
    const sortedStandings = [...nextStandings].sort(
      (a, b) => (a.position ?? 0) - (b.position ?? 0)
    );
    setStandings(sortedStandings);
  };

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      setErrorMessage("");

      try {
        setStandingsState(getPremierLeagueStandings());
      } catch (error) {
        console.log("Standings load error:", error);
        setErrorMessage("โหลดข้อมูลตารางคะแนนไม่สำเร็จ");
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating size="large" color="#facc15" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={require("../assets/logo.jpg")} style={styles.headerLogo} />
        <Text style={styles.title}>
          ตารางคะแนนพรีเมียร์ลีก {PREMIER_LEAGUE_SEASON_LABEL}
        </Text>
      </View>

      <Text style={styles.lastUpdatedText}>{lastUpdatedLabel}</Text>

      {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}

      <View style={styles.tableHeader}>
        <Text style={[styles.headerText, styles.rankCell]}>#</Text>
        <Text style={[styles.headerText, styles.clubCell, styles.clubHeader]}>สโมสร</Text>
        <Text style={[styles.headerText, styles.statCell]}>แข่ง</Text>
        <Text style={[styles.headerText, styles.statCell]}>ชนะ</Text>
        <Text style={[styles.headerText, styles.statCell]}>เสมอ</Text>
        <Text style={[styles.headerText, styles.statCell]}>แพ้</Text>
        <Text style={[styles.headerText, styles.statCell]}>ได้</Text>
        <Text style={[styles.headerText, styles.statCell]}>เสีย</Text>
        <Text style={[styles.headerText, styles.diffCell]}>ต่าง</Text>
        <Text style={[styles.headerText, styles.pointsCell]}>แต้ม</Text>
      </View>

      {standings.map((team, index) => {
        const crestUrl = getCrestUrl(team.team?.crest);
        let bgColor = "#1e293b";

        if (index < 4) bgColor = "#14532d";
        if (index >= standings.length - 3) bgColor = "#7f1d1d";

        return (
          <Card key={team.id} style={[styles.card, { backgroundColor: bgColor }]}>
            <Card.Content style={styles.row}>
              <Text style={[styles.text, styles.rankCell]}>{team.position}</Text>

              <View style={[styles.teamCell, styles.clubCell]}>
                {crestUrl ? (
                  <Image source={{ uri: crestUrl }} style={styles.teamLogo} />
                ) : (
                  <View style={styles.teamLogoFallback} />
                )}
                <Text style={styles.teamName} numberOfLines={1}>
                  {team.team?.shortName || team.team?.name || "-"}
                </Text>
              </View>

              <Text style={[styles.text, styles.statCell]}>{team.playedGames}</Text>
              <Text style={[styles.text, styles.statCell]}>{team.won}</Text>
              <Text style={[styles.text, styles.statCell]}>{team.draw}</Text>
              <Text style={[styles.text, styles.statCell]}>{team.lost}</Text>
              <Text style={[styles.text, styles.statCell]}>{team.goalsFor}</Text>
              <Text style={[styles.text, styles.statCell]}>{team.goalsAgainst}</Text>
              <Text style={[styles.text, styles.diffCell]}>{team.goalDifference}</Text>
              <Text style={[styles.pointsText, styles.pointsCell]}>{team.points}</Text>
            </Card.Content>
          </Card>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#233d7a",
    padding: 10,
  },

  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0f172a",
  },

  header: {
    alignItems: "center",
    marginBottom: 15,
  },

  headerLogo: {
    width: 100,
    height: 100,
    marginBottom: 8,
  },

  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#158ffa",
    textAlign: "center",
  },

  lastUpdatedText: {
    color: "#dbeafe",
    textAlign: "center",
    marginBottom: 10,
    fontSize: 12,
  },

  errorText: {
    color: "#fecaca",
    textAlign: "center",
    marginBottom: 10,
  },

  tableHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomColor: "#475569",
    borderBottomWidth: 1,
    paddingBottom: 6,
    marginBottom: 4,
  },

  headerText: {
    color: "#94a3b8",
    fontSize: 13,
    textAlign: "center",
    fontWeight: "600",
  },

  clubHeader: {
    textAlign: "left",
  },

  card: {
    marginBottom: 6,
    borderRadius: 10,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
  },

  text: {
    color: "#f8fafc",
    fontSize: 13,
    textAlign: "center",
  },

  pointsText: {
    color: "#eaf030",
    fontSize: 13,
    textAlign: "center",
    fontWeight: "bold",
  },

  rankCell: {
    flex: 0.6,
  },

  clubCell: {
    flex: 3,
  },

  statCell: {
    flex: 0.8,
  },

  diffCell: {
    flex: 0.9,
  },

  pointsCell: {
    flex: 1,
  },

  teamCell: {
    flexDirection: "row",
    alignItems: "center",
    flexShrink: 1,
  },

  teamLogo: {
    width: 25,
    height: 25,
    marginRight: 6,
    resizeMode: "contain",
    backgroundColor: "#fff",
    borderRadius: 4,
  },

  teamLogoFallback: {
    width: 25,
    height: 25,
    marginRight: 6,
    backgroundColor: "#334155",
    borderRadius: 4,
  },

  teamName: {
    color: "#f1f5f9",
    fontSize: 14,
    flexShrink: 1,
  },
});
