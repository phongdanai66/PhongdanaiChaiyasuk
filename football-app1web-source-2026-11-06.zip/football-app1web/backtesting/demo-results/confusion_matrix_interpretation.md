# DEMO — NOT REAL BACKTEST RESULTS

This report is simulated solely to demonstrate an interpretation format. It is not based on Gemini, Football-Data.org, or the real Backtesting output.

## Overall simulated result

- Matches: 1,140
- Correct: 667
- Incorrect: 473
- Accuracy: 58.51%
- Macro Precision: 54.83%
- Macro Recall: 54.55%
- Macro F1-score: 54.65%

## Simulated confusion matrix

Rows are actual outcomes; columns are predicted outcomes.

| Actual \ Predicted | HOME | DRAW | AWAY |
|---|---:|---:|---:|
| HOME | 375 | 80 | 65 |
| DRAW | 95 | 97 | 73 |
| AWAY | 80 | 80 | 195 |

Diagonal values are simulated correct predictions. Other values are simulated misclassifications.

## Simulated class interpretation

| Class | Actual | Correct | Incorrect | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| HOME | 520 | 375 | 145 | 68.18% | 72.12% | 70.09% |
| DRAW | 265 | 97 | 168 | 37.74% | 36.60% | 37.16% |
| AWAY | 355 | 195 | 160 | 58.56% | 54.93% | 56.69% |

## Simulated observed misclassifications

- Actual DRAW, predicted HOME: 95
- Actual HOME, predicted DRAW: 80
- Actual AWAY, predicted HOME: 80
- Actual AWAY, predicted DRAW: 80
- Actual DRAW, predicted AWAY: 73
- Actual HOME, predicted AWAY: 65
