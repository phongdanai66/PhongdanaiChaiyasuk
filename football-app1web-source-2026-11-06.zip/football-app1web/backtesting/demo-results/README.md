# DEMO — NOT REAL BACKTEST RESULTS

These files contain simulated figures only, created to demonstrate report and confusion-matrix formatting. They are not Gemini predictions, not Football-Data.org results, and must not be presented as an AI evaluation.

Real exports remain in `backtesting/results/`.
