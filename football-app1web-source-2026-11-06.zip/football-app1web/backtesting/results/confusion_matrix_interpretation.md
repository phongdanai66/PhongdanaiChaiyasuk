# Premier League AI Backtesting — Confusion Matrix Interpretation

Generated: 2026-10-08T17:21:09.412Z
Seasons represented: 2025/26

Rows are actual results; columns are Gemini predictions. TP/FP/FN/TN are one-vs-rest values for each class.

## Overall

- Matches evaluated: 80
- Correct predictions: 39
- Incorrect predictions: 41
- Accuracy: 48.75%
- Macro Precision: 38.84%
- Macro Recall: 36.80%
- Macro F1-score: 31.68%
- Highest Recall: HOME
- Lowest Recall: DRAW

## Confusion Matrix

| Actual \ Predicted | HOME | DRAW | AWAY |
|---|---:|---:|---:|
| HOME | 35 | 1 | 2 |
| DRAW | 17 | 1 | 1 |
| AWAY | 15 | 5 | 3 |

Diagonal cells are correct predictions. All other cells are misclassifications.

## Per-class interpretation

### HOME
- Actual games: 38
- Correct: 35
- Incorrect: 3
- Precision: 52.24%
- Recall: 92.11%
- F1-score: 66.67%
- One-vs-rest counts — TP: 35, FP: 32, FN: 3, TN: 10

### DRAW
- Actual games: 19
- Correct: 1
- Incorrect: 18
- Precision: 14.29%
- Recall: 5.26%
- F1-score: 7.69%
- One-vs-rest counts — TP: 1, FP: 6, FN: 18, TN: 55

### AWAY
- Actual games: 23
- Correct: 3
- Incorrect: 20
- Precision: 50.00%
- Recall: 13.04%
- F1-score: 20.69%
- One-vs-rest counts — TP: 3, FP: 3, FN: 20, TN: 54

## Observed misclassifications

- Actual DRAW, predicted HOME: 17
- Actual AWAY, predicted HOME: 15
- Actual AWAY, predicted DRAW: 5
- Actual HOME, predicted AWAY: 2
- Actual HOME, predicted DRAW: 1
- Actual DRAW, predicted AWAY: 1

## Notes

- Metrics are calculated by JavaScript from real completed prediction rows; Gemini does not calculate evaluation metrics.
- N/A means a denominator was zero, so the metric is not meaningful.
- This report states counts and metrics without a qualitative claim about the AI overall.
