import seasonData from "./premierLeagueSeason.json";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebaseConfig";

export const PREMIER_LEAGUE_SEASON = seasonData.season;
export const PREMIER_LEAGUE_SEASON_LABEL = seasonData.seasonLabel;
export const PREMIER_LEAGUE_PREVIOUS_SEASON_LABEL =
  seasonData.previousSeasonLabel;
export const PREMIER_LEAGUE_SYNCED_AT = seasonData.syncedAt;

export const getPremierLeagueMatches = () => [...seasonData.matches];

export const getPreviousPremierLeagueMatches = () => [
  ...seasonData.previousSeasonMatches,
];

// Includes the immediately previous season plus the older seasons retained
// for the statistical prediction model.
export const getPremierLeagueHistoricalMatches = () => {
  const archived = seasonData.historicalSeasonMatches ?? [];

  return archived.length
    ? archived.flatMap((season) => season.matches ?? [])
    : getPreviousPremierLeagueMatches();
};

export const getPremierLeagueStandings = () =>
  [...seasonData.standings].sort(
    (a, b) => (a.position ?? 0) - (b.position ?? 0)
  );

export const getPremierLeagueTeamSquad = (teamId) => {
  const team = seasonData.teams.find(
    (item) => String(item.id) === String(teamId)
  );

  return team ? [...team.squad] : [];
};

export const getPremierLeagueTeamNames = () =>
  getPremierLeagueStandings()
    .map((standing) => standing.team?.shortName || standing.team?.name)
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, "en"));

// The screen-oriented exports above deliberately remain synchronous so they can
// render from the bundled snapshot. The AI flow uses the loaders below, which
// prefer Firestore and only fall back to the same snapshot when offline or when
// Firestore is unavailable.
const toDocuments = (snapshot) =>
  snapshot.docs.map((snapshotDoc) => ({
    id: snapshotDoc.id,
    ...snapshotDoc.data(),
  }));

const asList = (value) => (Array.isArray(value) ? value : []);

const readCollection = async (...path) => {
  const snapshot = await getDocs(collection(db, ...path));
  return toDocuments(snapshot);
};

const useFallback = (label, error) => {
  console.warn(`Unable to load ${label} from Firestore; using bundled data.`, error);
};

let currentMatchesPromise;
let historicalMatchesPromise;
let standingsPromise;
let teamsPromise;

export const loadPremierLeagueMatchesForAI = () => {
  if (!currentMatchesPromise) {
    currentMatchesPromise = readCollection("matches")
      .then((matches) => {
        const list = asList(matches);
        return list.length ? list : getPremierLeagueMatches();
      })
      .catch((error) => {
        useFallback("current matches", error);
        return getPremierLeagueMatches();
      });
  }
  return currentMatchesPromise.then((matches) => [...matches]);
};

export const loadPremierLeagueHistoricalMatchesForAI = () => {
  if (!historicalMatchesPromise) {
    historicalMatchesPromise = readCollection("historicalSeasons")
      .then(async (seasons) => {
        const remoteSeasons = await Promise.all(
          seasons.map(async (season) => ({
            startYear: Number(season.startYear),
            matches: await readCollection("historicalSeasons", season.id, "matches"),
          }))
        );
        const matches = asList(remoteSeasons)
          .sort((left, right) => right.startYear - left.startYear)
          .flatMap((season) => asList(season.matches));

        return matches.length ? matches : getPremierLeagueHistoricalMatches();
      })
      .catch((error) => {
        useFallback("historical matches", error);
        return getPremierLeagueHistoricalMatches();
      });
  }
  return historicalMatchesPromise.then((matches) => [...matches]);
};

export const loadPremierLeagueStandingsForAI = () => {
  if (!standingsPromise) {
    standingsPromise = readCollection("standings")
      .then((standings) =>
        (asList(standings).length ? asList(standings) : getPremierLeagueStandings()).sort(
          (left, right) => (left.position ?? 0) - (right.position ?? 0)
        )
      )
      .catch((error) => {
        useFallback("standings", error);
        return getPremierLeagueStandings();
      });
  }
  return standingsPromise.then((standings) => [...standings]);
};

const loadPremierLeagueTeamsForAI = () => {
  if (!teamsPromise) {
    teamsPromise = readCollection("teams").catch((error) => {
      useFallback("team squads", error);
      return [];
    });
  }
  return teamsPromise.then((teams) => [...teams]);
};

export const loadPremierLeagueTeamSquadForAI = async (teamId) => {
  const teams = await loadPremierLeagueTeamsForAI();
  const team = teams.find((item) => String(item.id) === String(teamId));
  return team ? asList(team.squad) : getPremierLeagueTeamSquad(teamId);
};
