const fs = require("fs");
const path = require("path");
const admin = require("firebase-admin");

const FOOTBALL_DATA_BASE_URL = "https://api.football-data.org/v4";
const DEFAULT_COMPETITION = "PL";
const PROJECT_ID = "match-bb30c";

const getArgValue = (name) => {
  const prefix = `--${name}=`;
  const arg = process.argv.find((value) => value.startsWith(prefix));
  return arg ? arg.slice(prefix.length) : "";
};

const getServiceAccount = () => {
  const serviceAccountPath =
    process.env.FIREBASE_SERVICE_ACCOUNT_PATH ||
    process.env.GOOGLE_APPLICATION_CREDENTIALS ||
    getArgValue("service-account");

  if (!serviceAccountPath) {
    throw new Error(
      "Missing service account. Set FIREBASE_SERVICE_ACCOUNT_PATH or GOOGLE_APPLICATION_CREDENTIALS."
    );
  }

  const resolvedPath = path.resolve(serviceAccountPath);
  return JSON.parse(fs.readFileSync(resolvedPath, "utf8"));
};

const initializeFirebase = () => {
  if (admin.apps.length) {
    return;
  }

  admin.initializeApp({
    credential: admin.credential.cert(getServiceAccount()),
    projectId: PROJECT_ID,
  });
};

const normalizeSeason = (season) => {
  if (!season) {
    return null;
  }

  if (typeof season !== "object") {
    return {
      id: "",
      startDate: "",
      endDate: "",
      currentMatchday: "",
      startYear: String(season),
    };
  }

  return {
    id: season?.id ?? "",
    startDate: season?.startDate ?? "",
    endDate: season?.endDate ?? "",
    currentMatchday: season?.currentMatchday ?? "",
    startYear: season?.startYear ?? "",
  };
};

const normalizeMatch = (match, season = null, syncedAt) => ({
  id: match?.id ?? "",
  utcDate: match?.utcDate ?? "",
  status: match?.status ?? "",
  competition: match?.competition ?? null,
  season: normalizeSeason(match?.season ?? season),
  homeTeam: {
    id: match?.homeTeam?.id ?? "",
    name: match?.homeTeam?.name ?? "",
    shortName: match?.homeTeam?.shortName ?? "",
    crest: match?.homeTeam?.crest ?? "",
  },
  awayTeam: {
    id: match?.awayTeam?.id ?? "",
    name: match?.awayTeam?.name ?? "",
    shortName: match?.awayTeam?.shortName ?? "",
    crest: match?.awayTeam?.crest ?? "",
  },
  score: match?.score ?? {},
  lastSyncedAt: syncedAt,
});

const normalizeStanding = (standing, season = null, syncedAt) => ({
  id: standing?.team?.id ?? String(standing?.position ?? ""),
  position: standing?.position ?? 0,
  playedGames: standing?.playedGames ?? 0,
  won: standing?.won ?? 0,
  draw: standing?.draw ?? 0,
  lost: standing?.lost ?? 0,
  points: standing?.points ?? 0,
  goalsFor: standing?.goalsFor ?? 0,
  goalsAgainst: standing?.goalsAgainst ?? 0,
  goalDifference: standing?.goalDifference ?? 0,
  team: {
    id: standing?.team?.id ?? "",
    name: standing?.team?.name ?? "",
    shortName: standing?.team?.shortName ?? "",
    tla: standing?.team?.tla ?? "",
    crest: standing?.team?.crest ?? "",
  },
  season: normalizeSeason(season),
  lastSyncedAt: syncedAt,
});

const buildQueryString = (params = {}) => {
  const query = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      query.append(key, String(value));
    }
  });

  const text = query.toString();
  return text ? `?${text}` : "";
};

const requestFootballData = async (apiToken, route, params = {}) => {
  const response = await fetch(
    `${FOOTBALL_DATA_BASE_URL}${route}${buildQueryString(params)}`,
    {
      headers: { "X-Auth-Token": apiToken },
    }
  );

  if (!response.ok) {
    const details = await response.text().catch(() => "");
    throw new Error(
      `football-data.org request failed with status ${response.status}: ${details}`
    );
  }

  return response.json();
};

const getMatches = async (apiToken, competitionCode, syncedAt, options = {}) => {
  const data = await requestFootballData(
    apiToken,
    `/competitions/${competitionCode}/matches`,
    { season: options.season }
  );

  return (data?.matches ?? []).map((match) =>
    normalizeMatch(match, data?.season ?? options.season, syncedAt)
  );
};

const getStandings = async (apiToken, competitionCode, syncedAt, options = {}) => {
  const data = await requestFootballData(
    apiToken,
    `/competitions/${competitionCode}/standings`,
    { season: options.season }
  );
  const totalStanding =
    data?.standings?.find((standing) => standing?.type === "TOTAL") ??
    data?.standings?.[0];

  return (totalStanding?.table ?? []).map((standing) =>
    normalizeStanding(standing, data?.season, syncedAt)
  );
};

const writeCollection = async (db, collectionName, items) => {
  let batch = db.batch();
  let pendingWrites = 0;
  let totalWrites = 0;

  for (const item of items) {
    if (!item.id) {
      continue;
    }

    batch.set(db.collection(collectionName).doc(String(item.id)), item, {
      merge: true,
    });
    pendingWrites += 1;
    totalWrites += 1;

    if (pendingWrites === 450) {
      await batch.commit();
      batch = db.batch();
      pendingWrites = 0;
    }
  }

  if (pendingWrites > 0) {
    await batch.commit();
  }

  return totalWrites;
};

const syncPremierLeague = async () => {
  const apiToken = process.env.FOOTBALL_DATA_API_TOKEN || getArgValue("football-token");
  const competitionCode = (
    process.env.COMPETITION_CODE ||
    getArgValue("competition") ||
    DEFAULT_COMPETITION
  ).toUpperCase();
  const season = process.env.FOOTBALL_DATA_SEASON || getArgValue("season");

  if (!apiToken) {
    throw new Error(
      "Missing FOOTBALL_DATA_API_TOKEN. Set it as an environment variable or pass --football-token=..."
    );
  }

  initializeFirebase();

  const syncedAt = new Date().toISOString();
  const db = admin.firestore();

  console.log(
    `Syncing ${competitionCode}${season ? ` season ${season}` : ""} at ${syncedAt}`
  );
  const [matches, standings] = await Promise.all([
    getMatches(apiToken, competitionCode, syncedAt, { season }),
    getStandings(apiToken, competitionCode, syncedAt, { season }),
  ]);

  const [matchWrites, standingWrites] = await Promise.all([
    writeCollection(db, "matches", matches),
    writeCollection(db, "standings", standings),
  ]);

  const result = {
    source: "local-script",
    competitionCode,
    season: season || "current",
    matches: matchWrites,
    matchesFetched: matches.length,
    standings: standingWrites,
    standingsFetched: standings.length,
    syncedAt,
    updatedAt: new Date().toISOString(),
  };

  console.log(JSON.stringify(result, null, 2));
};

syncPremierLeague()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error.message || error);
    process.exit(1);
  });
