const admin = require("firebase-admin");
const { logger } = require("firebase-functions");
const { defineSecret } = require("firebase-functions/params");
const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");

admin.initializeApp();

const REGION = "us-central1";
const FOOTBALL_DATA_BASE_URL = "https://api.football-data.org/v4";
const DEFAULT_COMPETITION = "PL";
const MATCH_UPDATE_DELAY_MS = 3 * 60 * 60 * 1000;
const DATA_REFRESH_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000;

const footballDataApiToken = defineSecret("FOOTBALL_DATA_API_TOKEN");
const geminiApiKey = defineSecret("GEMINI_API_KEY");
const GEMINI_INTERACTIONS_URL =
  "https://generativelanguage.googleapis.com/v1beta/interactions";
const GEMINI_MODEL = "gemini-3.8-flash";

const TEAM_ALIASES = {
  "man city": "manchester city",
  "manchester city fc": "manchester city",
  "man united": "manchester united",
  "manchester united fc": "manchester united",
  wolves: "wolverhampton wanderers",
  "wolverhampton wanderers fc": "wolverhampton wanderers",
  tottenham: "tottenham hotspur",
  spurs: "tottenham hotspur",
  "tottenham hotspur fc": "tottenham hotspur",
  brighton: "brighton & hove albion",
  "brighton & hove albion fc": "brighton & hove albion",
  "west ham": "west ham united",
  "west ham united fc": "west ham united",
  newcastle: "newcastle united",
  "newcastle united fc": "newcastle united",
  "nott'm forest": "nottingham forest",
  "nottm forest": "nottingham forest",
};

const normalizeTeamName = (value = "") => {
  const normalized = value.trim().toLowerCase();
  return TEAM_ALIASES[normalized] || normalized;
};

const normalizeSeason = (season) => {
  if (!season) {
    return null;
  }

  if (typeof season !== "object") {
    return {
      id: "",
      startDate: "",
      endDate: "",
      currentMatchday: "",
      startYear: String(season),
    };
  }

  return {
    id: season?.id ?? "",
    startDate: season?.startDate ?? "",
    endDate: season?.endDate ?? "",
    currentMatchday: season?.currentMatchday ?? "",
    startYear: season?.startYear ?? "",
  };
};

const normalizeMatch = (match, season = null) => ({
  id: match?.id ?? "",
  utcDate: match?.utcDate ?? "",
  status: match?.status ?? "",
  competition: match?.competition ?? null,
  season: normalizeSeason(match?.season ?? season),
  homeTeam: {
    id: match?.homeTeam?.id ?? "",
    name: match?.homeTeam?.name ?? "",
    shortName: match?.homeTeam?.shortName ?? "",
    crest: match?.homeTeam?.crest ?? "",
  },
  awayTeam: {
    id: match?.awayTeam?.id ?? "",
    name: match?.awayTeam?.name ?? "",
    shortName: match?.awayTeam?.shortName ?? "",
    crest: match?.awayTeam?.crest ?? "",
  },
  score: match?.score ?? {},
  lastSyncedAt: new Date().toISOString(),
});

const normalizeStanding = (standing, season = null) => ({
  id: standing?.team?.id ?? String(standing?.position ?? ""),
  position: standing?.position ?? 0,
  playedGames: standing?.playedGames ?? 0,
  won: standing?.won ?? 0,
  draw: standing?.draw ?? 0,
  lost: standing?.lost ?? 0,
  points: standing?.points ?? 0,
  goalsFor: standing?.goalsFor ?? 0,
  goalsAgainst: standing?.goalsAgainst ?? 0,
  goalDifference: standing?.goalDifference ?? 0,
  team: {
    id: standing?.team?.id ?? "",
    name: standing?.team?.name ?? "",
    shortName: standing?.team?.shortName ?? "",
    tla: standing?.team?.tla ?? "",
    crest: standing?.team?.crest ?? "",
  },
  season: normalizeSeason(season),
  lastSyncedAt: new Date().toISOString(),
});

const normalizeSquadMember = (player) => ({
  id: player?.id ?? "",
  name: player?.name ?? "",
  firstName: player?.firstName ?? "",
  lastName: player?.lastName ?? "",
  position: player?.position ?? "",
  dateOfBirth: player?.dateOfBirth ?? "",
  nationality: player?.nationality ?? "",
  shirtNumber: player?.shirtNumber ?? null,
});

const buildQueryString = (params = {}) => {
  const query = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      query.append(key, String(value));
    }
  });

  const text = query.toString();
  return text ? `?${text}` : "";
};

const requestFootballData = async (path, params = {}) => {
  const token = footballDataApiToken.value();

  if (!token) {
    const error = new Error("Missing FOOTBALL_DATA_API_TOKEN secret.");
    error.status = 500;
    throw error;
  }

  const response = await fetch(
    `${FOOTBALL_DATA_BASE_URL}${path}${buildQueryString(params)}`,
    {
      headers: { "X-Auth-Token": token },
    }
  );

  if (!response.ok) {
    const details = await response.text().catch(() => "");
    const error = new Error(
      `football-data.org request failed with status ${response.status}`
    );
    error.status = response.status;
    error.details = details;
    throw error;
  }

  return response.json();
};

const getMatches = async (competitionCode = DEFAULT_COMPETITION, options = {}) => {
  const data = await requestFootballData(
    `/competitions/${competitionCode}/matches`,
    { season: options.season }
  );

  return (data?.matches ?? []).map((match) =>
    normalizeMatch(match, data?.season ?? options.season)
  );
};

const getStandings = async (competitionCode = DEFAULT_COMPETITION) => {
  const data = await requestFootballData(
    `/competitions/${competitionCode}/standings`
  );
  const totalStanding =
    data?.standings?.find((standing) => standing?.type === "TOTAL") ??
    data?.standings?.[0];

  return (totalStanding?.table ?? []).map((standing) =>
    normalizeStanding(standing, data?.season)
  );
};

const getTeamSquad = async (teamId) => {
  if (!teamId) {
    return [];
  }

  const data = await requestFootballData(`/teams/${teamId}`);
  return (data?.squad ?? [])
    .map(normalizeSquadMember)
    .filter((player) => player.name);
};

const findStanding = (standings, teamName) => {
  const target = normalizeTeamName(teamName);

  return (
    standings.find((standing) => {
      const names = [
        standing.team?.name,
        standing.team?.shortName,
        standing.team?.tla,
      ]
        .filter(Boolean)
        .map((name) => normalizeTeamName(name));

      return names.includes(target);
    }) || null
  );
};

const readExistingMatches = async (firestore) => {
  const snapshot = await firestore.collection("matches").get();
  const matches = new Map();

  snapshot.forEach((doc) => {
    matches.set(doc.id, doc.data() || {});
  });

  return matches;
};

const hasStoredStandings = async (firestore) => {
  const snapshot = await firestore.collection("standings").limit(1).get();
  return !snapshot.empty;
};

const hasNewlyFinishedMatch = (matches, existingStatuses) =>
  matches.some((match) => {
    const matchId = String(match.id);
    const previousStatus = existingStatuses.get(matchId);

    return match.status === "FINISHED" && previousStatus !== "FINISHED";
  });

const getLatestMatchSyncedAt = (existingMatches) =>
  [...existingMatches.values()].reduce((latest, match) => {
    const syncedAt = Date.parse(match.lastSyncedAt || "");
    return Number.isNaN(syncedAt) ? latest : Math.max(latest, syncedAt);
  }, 0);

const isStoredDataStale = (existingMatches, now = Date.now()) => {
  if (existingMatches.size === 0) {
    return true;
  }

  const latestSyncedAt = getLatestMatchSyncedAt(existingMatches);
  return !latestSyncedAt || now - latestSyncedAt >= DATA_REFRESH_INTERVAL_MS;
};

const shouldFetchLatestMatches = (existingMatches, now = Date.now()) => {
  if (isStoredDataStale(existingMatches, now)) {
    return true;
  }

  for (const match of existingMatches.values()) {
    const matchTime = Date.parse(match.utcDate || "");

    if (Number.isNaN(matchTime)) {
      continue;
    }

    if (match.status !== "FINISHED" && now >= matchTime + MATCH_UPDATE_DELAY_MS) {
      return true;
    }
  }

  return false;
};

const shouldSaveMatch = (match, existingStatuses, refreshExisting = false) => {
  if (refreshExisting) {
    return true;
  }

  const matchId = String(match.id);
  const previousStatus = existingStatuses.get(matchId);

  return !(match.status === "FINISHED" && previousStatus === "FINISHED");
};

const syncPremierLeagueData = async (
  competitionCode = DEFAULT_COMPETITION,
  options = {}
) => {
  const db = admin.firestore();
  const existingMatches = await readExistingMatches(db);

  if (!options.force && !shouldFetchLatestMatches(existingMatches)) {
    const result = {
      competitionCode,
      skipped: true,
      reason: "No stored match is past its update window.",
      syncedAt: new Date().toISOString(),
    };

    return result;
  }

  const existingStatuses = new Map(
    [...existingMatches.entries()].map(([matchId, match]) => [
      matchId,
      match?.status || "",
    ])
  );
  const refreshExisting = Boolean(options.force) || isStoredDataStale(existingMatches);
  const [matches, standingsAlreadyStored] = await Promise.all([
    getMatches(competitionCode),
    hasStoredStandings(db),
  ]);
  const shouldSyncStandings =
    refreshExisting ||
    options.forceStandings ||
    !standingsAlreadyStored ||
    hasNewlyFinishedMatch(matches, existingStatuses);
  const standings = shouldSyncStandings ? await getStandings(competitionCode) : [];
  const matchesToSave = matches.filter((match) =>
    shouldSaveMatch(match, existingStatuses, refreshExisting)
  );
  const batch = db.batch();

  matchesToSave.forEach((match) => {
    batch.set(db.collection("matches").doc(String(match.id)), match, {
      merge: true,
    });
  });

  standings.forEach((standing) => {
    batch.set(db.collection("standings").doc(String(standing.id)), standing, {
      merge: true,
    });
  });

  const writeCount = matchesToSave.length + standings.length;

  if (writeCount > 0) {
    await batch.commit();
  }

  const result = {
    competitionCode,
    skipped: false,
    matches: matchesToSave.length,
    matchesFetched: matches.length,
    standings: standings.length,
    standingsSkipped: !shouldSyncStandings,
    writes: writeCount,
    forced: Boolean(options.force),
    refreshedByAge: refreshExisting,
    syncedAt: new Date().toISOString(),
  };

  return result;
};

const getRoute = (req) => {
  const rawPath = req.path || new URL(req.url, "https://localhost").pathname;
  const withoutTrailingSlash = rawPath.replace(/\/+$/, "") || "/";

  if (withoutTrailingSlash === "/api") {
    return "/";
  }

  return withoutTrailingSlash.startsWith("/api/")
    ? withoutTrailingSlash.replace(/^\/api/, "")
    : withoutTrailingSlash;
};

const getBody = (req) => {
  if (!req.body) {
    return {};
  }

  if (typeof req.body === "string") {
    try {
      return JSON.parse(req.body);
    } catch (error) {
      return {};
    }
  }

  return req.body;
};

const sendJson = (res, status, data) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.status(status).json(data);
};

const getGeminiText = (interaction) => {
  const modelStep = [...(interaction?.steps || [])]
    .reverse()
    .find((step) => step?.type === "model_output");
  const text = (modelStep?.content || [])
    .filter((item) => item?.type === "text")
    .map((item) => item.text || "")
    .join("")
    .trim();

  if (!text) {
    throw new Error("Gemini returned no text output.");
  }

  return text;
};

const generateGeminiAnalysis = async (prompt) => {
  const response = await fetch(GEMINI_INTERACTIONS_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": geminiApiKey.value(),
    },
    body: JSON.stringify({ model: GEMINI_MODEL, input: prompt }),
  });
  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(
      payload?.error?.message || `Gemini request failed (${response.status}).`
    );
    error.status = response.status;
    throw error;
  }

  return getGeminiText(payload);
};

exports.syncPremierLeagueNow = onRequest(
  {
    region: REGION,
    cors: true,
    timeoutSeconds: 300,
    memory: "512MiB",
    secrets: [footballDataApiToken],
  },
  async (req, res) => {
    if (req.method === "OPTIONS") {
      sendJson(res, 204, {});
      return;
    }

    if (req.method !== "POST") {
      sendJson(res, 405, { error: "Method not allowed" });
      return;
    }

    try {
      const body = getBody(req);
      const competitionCode = String(
        body.competitionCode || req.query.competitionCode || DEFAULT_COMPETITION
      ).toUpperCase();
      const result = await syncPremierLeagueData(competitionCode, {
        force: body.force !== false,
        forceStandings: body.forceStandings !== false,
      });

      sendJson(res, 200, result);
    } catch (error) {
      logger.error("Manual Premier League sync failed", {
        message: error.message,
        details: error.details,
      });
      sendJson(res, error.status || 500, {
        error: error.message || "Internal server error",
      });
    }
  }
);

exports.api = onRequest(
  {
    region: REGION,
    cors: true,
    timeoutSeconds: 180,
    memory: "512MiB",
    secrets: [footballDataApiToken, geminiApiKey],
  },
  async (req, res) => {
    if (req.method === "OPTIONS") {
      sendJson(res, 204, {});
      return;
    }

    try {
      const route = getRoute(req);
      const competitionCode =
        String(req.query.competitionCode || DEFAULT_COMPETITION).toUpperCase();

      if (req.method === "GET" && route === "/health") {
        sendJson(res, 200, { ok: true });
        return;
      }

      if (req.method === "POST" && route === "/sync-premier-league") {
        const body = getBody(req);
        const result = await syncPremierLeagueData(competitionCode, {
          force: Boolean(body.force),
          forceStandings: Boolean(body.forceStandings),
        });
        sendJson(res, 200, result);
        return;
      }

      if (req.method === "POST" && route === "/ai-analysis") {
        const body = getBody(req);
        const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
        if (!prompt) {
          sendJson(res, 400, { error: "Missing analysis prompt." });
          return;
        }
        if (prompt.length > 50000) {
          sendJson(res, 400, { error: "Analysis prompt is too large." });
          return;
        }

        const analysis = await generateGeminiAnalysis(prompt);
        sendJson(res, 200, { analysis, model: GEMINI_MODEL });
        return;
      }

      if (req.method === "GET" && route === "/matches") {
        const matches = await getMatches(competitionCode, {
          season: req.query.season,
        });
        sendJson(res, 200, { matches });
        return;
      }

      if (req.method === "GET" && route === "/standings") {
        const standings = await getStandings(competitionCode);
        sendJson(res, 200, { standings });
        return;
      }

      if (req.method === "GET" && route === "/team-squad") {
        const squad = await getTeamSquad(req.query.teamId);
        sendJson(res, 200, { squad });
        return;
      }

      if (req.method === "GET" && route === "/premier-league-teams") {
        const standings = await getStandings(DEFAULT_COMPETITION);
        const teams = standings
          .map((standing) => standing.team?.shortName || standing.team?.name)
          .filter(Boolean);
        sendJson(res, 200, { teams });
        return;
      }

      sendJson(res, 404, { error: "Not found" });
    } catch (error) {
      logger.error("API request failed", {
        message: error.message,
        details: error.details,
      });
      sendJson(res, error.status || 500, {
        error: error.message || "Internal server error",
      });
    }
  }
);

exports.syncPremierLeagueSchedule = onSchedule(
  {
    region: REGION,
    schedule: "every 7 days",
    timeZone: "Asia/Bangkok",
    timeoutSeconds: 300,
    memory: "512MiB",
    secrets: [footballDataApiToken],
  },
  async () => {
    const result = await syncPremierLeagueData(DEFAULT_COMPETITION);
    logger.info("Premier League data synced", result);
  }
);
